#!/usr/bin/env python3
import time, re
from pathlib import Path
import pandas as pd
import requests

START_YEAR, END_YEAR = 2018, 2024
OUT = Path("external_debt_download"); OUT.mkdir(exist_ok=True)
COUNTRIES = ["ARG","BOL","BRA","CHL","COL","CRI","DOM","ECU","SLV","GTM","HND","MEX","NIC","PAN","PRY","PER","URY","VEN"]
CC = ";".join(COUNTRIES)

ANNUAL = {
"DT.DOD.DSTC.CD":"short_term_external_debt_usd",
"DT.DOD.DSTC.IR.ZS":"short_term_debt_pct_reserves_wb",
"DT.DOD.DSTC.ZS":"short_term_debt_pct_total_external_debt",
"DT.DOD.DECT.CD":"total_external_debt_usd",
"DT.DOD.DPPG.CD":"external_ppg_debt_usd",
"DT.CUR.USDL.ZS":"ppg_currency_share_usd_pct",
"DT.CUR.EURO.ZS":"ppg_currency_share_euro_pct",
"DT.CUR.JYEN.ZS":"ppg_currency_share_jpy_pct",
"DT.CUR.UKPS.ZS":"ppg_currency_share_gbp_pct",
"DT.CUR.SDRW.ZS":"ppg_currency_share_sdr_pct",
"DT.CUR.MULC.ZS":"ppg_currency_share_multiple_pct",
"DT.CUR.OTHC.ZS":"ppg_currency_share_other_pct",
"NY.GDP.MKTP.CD":"gdp_current_usd",
"FI.RES.XGLD.CD":"reserves_excluding_gold_usd",
"FI.RES.TOTL.CD":"reserves_including_gold_usd"}

S=requests.Session(); S.headers["User-Agent"]="Mozilla/5.0 stablecoin-research/1.0"
LOG=[]
def log(x): print(x); LOG.append(str(x))
def getj(url,params=None):
    err=None
    for k in range(5):
        try:
            r=S.get(url,params=params,timeout=60); r.raise_for_status(); return r.json()
        except Exception as e:
            err=e; time.sleep(2**k)
    raise RuntimeError(f"{url}: {err}")

def indicator(code, source=None, date="2018:2024"):
    u=f"https://api.worldbank.org/v2/country/{CC}/indicator/{code}"
    p={"format":"json","per_page":20000,"date":date}
    if source: p["source"]=source
    j=getj(u,p)
    if not isinstance(j,list) or len(j)<2 or j[1] is None: return pd.DataFrame()
    return pd.DataFrame([{"country":x.get("countryiso3code"),"country_name":(x.get("country") or {}).get("value"),
                          "period":x.get("date"),"indicator":code,
                          "indicator_name":(x.get("indicator") or {}).get("value"),"value":x.get("value")} for x in j[1]])

# Annual IDS/WDI
frames=[]
for code,alias in ANNUAL.items():
    log(f"Annual: {code}")
    try:
        d=indicator(code)
        if not d.empty: d["alias"]=alias; frames.append(d)
    except Exception as e: log(f"ERROR {code}: {e}")
if frames:
    a=pd.concat(frames,ignore_index=True); a["year"]=pd.to_numeric(a.period,errors="coerce")
    a=a[a.country.isin(COUNTRIES)]
    a.to_csv(OUT/"annual_debt_raw_long.csv",index=False)
    w=a.pivot_table(index=["country","country_name","year"],columns="alias",values="value",aggfunc="first").reset_index()
    w.columns.name=None
    def rat(n,d): return 100*pd.to_numeric(w.get(n),errors="coerce")/pd.to_numeric(w.get(d),errors="coerce")
    w["x_st_external_debt_pct_gdp"]=rat("short_term_external_debt_usd","gdp_current_usd")
    w["x_st_external_debt_pct_reserves_exgold"]=rat("short_term_external_debt_usd","reserves_excluding_gold_usd")
    w["x_st_external_debt_pct_reserves_inclgold"]=rat("short_term_external_debt_usd","reserves_including_gold_usd")
    if "external_ppg_debt_usd" in w and "ppg_currency_share_usd_pct" in w:
        w["x_usd_external_ppg_debt_usd"]=w.external_ppg_debt_usd*w.ppg_currency_share_usd_pct/100
        w["x_usd_external_ppg_debt_pct_gdp"]=100*w.x_usd_external_ppg_debt_usd/w.gdp_current_usd
    w.to_csv(OUT/"annual_debt_wide_2018_2024.csv",index=False)
    cov=[]
    for c in COUNTRIES:
        for v in [x for x in w.columns if x not in ["country","country_name","year"]]:
            z=w[(w.country==c)&w[v].notna()]
            cov.append([c,v,len(z),z.year.min() if len(z) else None,z.year.max() if len(z) else None])
    pd.DataFrame(cov,columns=["country","variable","n_nonmissing","first_year","last_year"]).to_csv(OUT/"annual_coverage_report.csv",index=False)

# QEDS: dynamically discover source IDs and series IDs
log("Discovering QEDS sources")
j=getj("https://api.worldbank.org/v2/sources",{"format":"json","per_page":500})
sources=pd.DataFrame(j[1]); sources.to_csv(OUT/"qeds_source_inventory.csv",index=False)
q=sources[sources.name.str.contains("Quarterly External Debt",case=False,na=False)]
invs=[]
for sid in q.id.astype(str):
    log(f"QEDS metadata source {sid}")
    try:
        j=getj(f"https://api.worldbank.org/v2/sources/{sid}/series/data",{"format":"json","per_page":50000})
        rows=[]
        if isinstance(j,dict):
            for so in j.get("source",[]):
                for co in so.get("concept",[]):
                    for v in co.get("variable",[]):
                        rows.append([sid,so.get("name"),v.get("id"),v.get("value")])
        invs.append(pd.DataFrame(rows,columns=["source_id","source_name","series_id","series_name"]))
    except Exception as e: log(f"QEDS metadata ERROR: {e}")

if invs:
    inv=pd.concat(invs,ignore_index=True).drop_duplicates()
    inv.to_csv(OUT/"qeds_series_inventory.csv",index=False)
    txt=inv.series_name.fillna("").str.lower()
    rel=inv[txt.str.contains(r"external debt|gross ext|short.?term",regex=True)].copy()
    pri=rel.series_name.fillna("").str.lower().str.contains(
        r"short.?term|general government|central bank|deposit.?taking|bank|other sectors|public sector|private sector|foreign currency|domestic currency|all sectors|all instruments|usd|u\.s\. dollar",regex=True)
    sel=rel[pri].copy()
    if sel.empty: sel=rel.copy()
    sel=sel.head(400)
    sel.to_csv(OUT/"qeds_selected_series.csv",index=False)
    qf=[]
    for _,r in sel.iterrows():
        log(f"QEDS {r.source_id} {r.series_id}")
        try:
            d=indicator(str(r.series_id),str(r.source_id),"2018Q1:2024Q4")
            if not d.empty:
                d["source_id"]=str(r.source_id); d["series_name_metadata"]=r.series_name; qf.append(d)
        except Exception as e: log(f"QEDS data ERROR: {e}")
    if qf:
        qr=pd.concat(qf,ignore_index=True); qr=qr[qr.country.isin(COUNTRIES)]
        qr.to_csv(OUT/"qeds_raw_long_2018Q1_2024Q4.csv",index=False)
        qc=(qr.assign(nonmissing=qr.value.notna()).groupby(["source_id","indicator","series_name_metadata","country"],dropna=False)
            .agg(n_rows=("period","size"),n_nonmissing=("nonmissing","sum"),first_period=("period","min"),last_period=("period","max")).reset_index())
        qc.to_csv(OUT/"qeds_coverage_report.csv",index=False)

(OUT/"README.txt").write_text("""Standalone external-debt extension for the LATAM18 stablecoin project.
Annual window: 2018-2024. QEDS window: 2018Q1-2024Q4.
The script does NOT merge with or modify the existing master panel.
Annual IDS/WDI and quarterly QEDS are kept separate because their concepts/methodologies differ.
QEDS participation is voluntary; coverage by sector, maturity and currency varies by country.
Upload the entire external_debt_download folder (preferably ZIP) for validation before merging.
""")
(OUT/"download_log.txt").write_text("\n".join(LOG))
print("DONE. Zip external_debt_download and upload it for validation.")
