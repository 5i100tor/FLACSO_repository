#!/usr/bin/env python3
import argparse,json,time,sys
from pathlib import Path
import pandas as pd, numpy as np, requests
UA={"User-Agent":"Mozilla/5.0 (StablecoinResearch/1.0)"}
def get(url,params=None):
 r=requests.get(url,params=params,headers=UA,timeout=45); r.raise_for_status(); return r.json()
def save(j,p): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(j,ensure_ascii=False,indent=2))
def arg(start,end,raw):
 # MonedAPI history endpoint; download in calendar-year chunks.
 # One request per origin/year instead of one request per day.
 frames=[]
 years=range(pd.Timestamp(start).year,pd.Timestamp(end).year+1)
 for origin in ["oficial","blue"]:
  pts=[]
  for yr in years:
   lo=max(pd.Timestamp(start),pd.Timestamp(f"{yr}-01-01")).strftime("%Y-%m-%d")
   hi=min(pd.Timestamp(end),pd.Timestamp(f"{yr}-12-31")).strftime("%Y-%m-%d")
   print(f"ARG {origin}: {lo} to {hi} ...",flush=True)
   url=f"https://monedapi.ar/api/v2/history/usd/{origin}"
   try:
    r=requests.get(url,params={"date_from":lo,"date_to":hi,"limit":500},headers=UA,timeout=60)
    if r.status_code==429:
     wait=int(r.headers.get("Retry-After","10")); print(f"  rate limited; waiting {wait}s",flush=True); time.sleep(wait)
     r=requests.get(url,params={"date_from":lo,"date_to":hi,"limit":500},headers=UA,timeout=60)
    r.raise_for_status(); j=r.json()
    save(j,raw/f"ARG_{origin}_{yr}.json")
    print(f"  received {len(j)} observations",flush=True)
    for q in j:
     a=pd.to_numeric(q.get("buy"),errors="coerce"); b=pd.to_numeric(q.get("sell"),errors="coerce")
     rate=(a+b)/2 if pd.notna(a) and pd.notna(b) else (b if pd.notna(b) else a)
     pts.append([pd.to_datetime(q.get("createdAt"),errors="coerce",utc=True),rate])
   except Exception as e:
    print(f"  WARNING {origin} {yr}: {e}",file=sys.stderr,flush=True)
   time.sleep(.15)
  z=pd.DataFrame(pts,columns=["timestamp",origin]).dropna(subset=["timestamp"])
  z["date"]=z.timestamp.dt.tz_convert("America/Argentina/Buenos_Aires").dt.tz_localize(None).dt.normalize()
  z=z.sort_values("timestamp").groupby("date",as_index=False)[origin].last()
  frames.append(z)
 if len(frames)!=2: raise RuntimeError("ARG historical download incomplete")
 y=frames[0].merge(frames[1],on="date",how="outer").sort_values("date")
 # Carry the last observed quote across non-trading days only within the requested history.
 y[["oficial","blue"]]=y[["oficial","blue"]].ffill()
 y=y[y.date.between(pd.Timestamp(start),pd.Timestamp(end))]
 y=y.rename(columns={"oficial":"official_rate","blue":"parallel_rate"})
 print(f"ARG complete: {len(y)} dated observations",flush=True)
 return y.assign(country="ARG",parallel_source="MonedAPI blue history",official_source="MonedAPI official history")
def bol(start,end,raw):
 j=get("https://paralelo.bo/api/v1/historical.json"); save(j,raw/"BOL_paralelo_bo.json")
 data=j if isinstance(j,list) else j.get("data",j.get("history",j.get("points",[])))
 x=pd.json_normalize(data)
 dc=next((c for c in x if c.lower() in ["date","fecha","time","timestamp","datetime","created_at"]),None)
 if not dc: raise RuntimeError("BOL date field not found: "+str(list(x.columns)))
 x["date"]=pd.to_datetime(x[dc],errors="coerce",utc=True).dt.tz_localize(None).dt.normalize()
 rate=None
 for c in x:
  if any(k in c.lower() for k in ["median","average","promedio","rate","price","venta","sell"]):
   z=pd.to_numeric(x[c],errors="coerce")
   if z.notna().sum()>10: rate=z; break
 if rate is None: raise RuntimeError("BOL rate field not found: "+str(list(x.columns)))
 x["parallel_rate"]=rate; x["official_rate"]=6.96
 x=x[x.date.between(pd.Timestamp(start),pd.Timestamp(end))]
 return x[["date","official_rate","parallel_rate"]].assign(country="BOL",parallel_source="paralelo.bo P2P",official_source="6.96 official-regime constant (flagged)")
def ven(start,end,raw):
 j=get("https://ve.dolarapi.com/v1/historicos/dolares"); save(j,raw/"VEN_dolarapi.json")
 x=pd.json_normalize(j); x["date"]=pd.to_datetime(x["fecha"],errors="coerce").dt.tz_localize(None).dt.normalize()
 x["rate"]=pd.to_numeric(x.get("promedio"),errors="coerce")
 if x["rate"].isna().all(): x["rate"]=(pd.to_numeric(x["compra"],errors="coerce")+pd.to_numeric(x["venta"],errors="coerce"))/2
 s=x["fuente"].astype(str).str.lower(); off=x[s.str.contains("bcv|oficial")].groupby("date").rate.last()
 par=x[~s.str.contains("bcv|oficial")].groupby("date").rate.last()
 y=pd.concat([off.rename("official_rate"),par.rename("parallel_rate")],axis=1).reset_index()
 y=y[y.date.between(pd.Timestamp(start),pd.Timestamp(end))]
 return y.assign(country="VEN",parallel_source="DolarApi/Yadio",official_source="DolarApi/BCV")
def monthly(raw):
 x=raw.sort_values(["country","date"]).copy()
 x["parallel_premium_pct"]=100*(x.parallel_rate/x.official_rate-1); x["year_month"]=x.date.dt.to_period("M").dt.to_timestamp()
 last=lambda s:s.dropna().iloc[-1] if s.notna().any() else np.nan
 m=x.groupby(["country","year_month"]).agg(official_rate_eom=("official_rate",last),parallel_rate_eom=("parallel_rate",last),
  parallel_premium_mean_pct=("parallel_premium_pct","mean"),parallel_premium_median_pct=("parallel_premium_pct","median"),
  parallel_premium_eom_pct=("parallel_premium_pct",last),parallel_premium_sd_pct=("parallel_premium_pct","std"),
  parallel_premium_max_pct=("parallel_premium_pct","max"),n_daily_obs=("parallel_premium_pct","count")).reset_index()
 m["x_shadow_dollar_scarcity"]=m.parallel_premium_eom_pct
 m["x_d_shadow_dollar_scarcity_pp"]=m.groupby("country").x_shadow_dollar_scarcity.diff()
 m["x_parallel_fx_dep_mom_pct"]=100*m.groupby("country").parallel_rate_eom.transform(lambda s:np.log(s).diff())
 m["x_official_fx_dep_mom_pct"]=100*m.groupby("country").official_rate_eom.transform(lambda s:np.log(s).diff())
 for q in [10,25,50,100]: m[f"x_premium_ge_{q}pct"]=(m.x_shadow_dollar_scarcity>=q).astype("Int64")
 return x,m
def main():
 a=argparse.ArgumentParser(); a.add_argument("--start",default="2018-01-01"); a.add_argument("--end",default="2025-12-31")
 a.add_argument("--out",default="parallel_fx_premium_data_v2"); a.add_argument("--skip-argentina",action="store_true"); z=a.parse_args()
 root=Path(z.out); raw=root/"data_raw"; proc=root/"data_processed"; meta=root/"metadata"
 for q in [raw,proc,meta]: q.mkdir(parents=True,exist_ok=True)
 jobs=[] if z.skip_argentina else [("ARG",arg)]; jobs += [("BOL",bol),("VEN",ven)]
 frames=[]; errs=[]
 for c,f in jobs:
  print("\nDownloading",c)
  try: frames.append(f(z.start,z.end,raw))
  except Exception as e: errs.append([c,repr(e)]); print("ERROR",c,e,file=sys.stderr)
 if not frames: raise SystemExit("No downloads succeeded")
 daily,m=monthly(pd.concat(frames,ignore_index=True)); daily.to_csv(proc/"parallel_fx_daily.csv",index=False); m.to_csv(proc/"parallel_fx_monthly.csv",index=False)
 cov=m.groupby("country").agg(first_month=("year_month","min"),last_month=("year_month","max"),months=("year_month","nunique"),
  months_with_premium=("x_shadow_dollar_scarcity","count"),median_daily_obs=("n_daily_obs","median")).reset_index()
 cov.to_csv(meta/"coverage.csv",index=False); pd.DataFrame(errs,columns=["country","error"]).to_csv(meta/"download_errors.csv",index=False)
 (meta/"README.txt").write_text("""Primary variable: x_shadow_dollar_scarcity = 100*(parallel/official-1), month-end.
ARG: MonedAPI blue vs official. BOL: paralelo.bo P2P; 6.96 official rate explicitly flagged as regime constant.
VEN: DolarApi/Yadio parallel vs BCV official. No interpolation. Inspect coverage before merging.
""")
 print(cov.to_string(index=False))
if __name__=="__main__": main()
