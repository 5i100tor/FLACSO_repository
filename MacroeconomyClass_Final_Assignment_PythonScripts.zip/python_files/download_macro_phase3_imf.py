#!/usr/bin/env python3
"""
download_macro_phase3_imf.py

Fill the LATAM18 monthly CPI/inflation and interest-rate gaps left by BIS,
using the IMF's current SDMX 3.0 API.

Primary sources:
  IMF.STA/CPI     - Consumer Price Index
  IMF.STA/MFS_IR  - Monetary and Financial Statistics, Interest Rates

Default sample: 2018-01 through 2025-12.

Important design:
- CPI is downloaded as national all-items CPI index, monthly.
- Inflation MoM and YoY are derived from the CPI index.
- Interest-rate data are downloaded broadly from MFS_IR.
- The script prefers a series explicitly labelled policy/central-bank/official/
  target/refinancing rate. If unavailable, it may use a money-market/interbank
  rate ONLY as a flagged proxy.
- It NEVER turns a missing policy rate into zero.
- Dollarized economies may legitimately lack an independent domestic policy rate.
- Raw IMF responses and a country-by-country selection audit are saved.

Install:
  python -m pip install pandas numpy requests

Run:
  python3 download_macro_phase3_imf.py

Optional:
  python3 download_macro_phase3_imf.py --all-latam
"""

from __future__ import annotations
import argparse, io, re, time
from pathlib import Path
import numpy as np
import pandas as pd
import requests

BASE="https://api.imf.org/external/sdmx/3.0"
HEADERS={"Accept":"text/csv","User-Agent":"academic-stablecoin-macro-research/phase3"}

LATAM18={
 "ARG":"Argentina","BOL":"Bolivia","BRA":"Brazil","CHL":"Chile","COL":"Colombia",
 "CRI":"Costa Rica","DOM":"Dominican Republic","ECU":"Ecuador","SLV":"El Salvador",
 "GTM":"Guatemala","HND":"Honduras","MEX":"Mexico","NIC":"Nicaragua","PAN":"Panama",
 "PRY":"Paraguay","PER":"Peru","URY":"Uruguay","VEN":"Venezuela"
}
# Missing from our BIS v4 CPI/policy layer:
MISSING=["BOL","CRI","DOM","ECU","SLV","GTM","HND","NIC","PAN","PRY","URY","VEN"]

def get(url,retries=4):
    err=None
    for i in range(retries):
        try:
            r=requests.get(url,headers=HEADERS,timeout=180)
            r.raise_for_status()
            if not r.text.strip():
                raise RuntimeError("Empty response")
            return r
        except Exception as e:
            err=e; time.sleep(2*(i+1))
    raise RuntimeError(f"{url}\n{err}")

def read_csv_url(url):
    r=get(url)
    try:
        return pd.read_csv(io.StringIO(r.text),low_memory=False), r.text
    except Exception as e:
        raise RuntimeError(f"IMF response was not parseable CSV: {e}\nFirst 500 chars:\n{r.text[:500]}")

def machine_code(x):
    if pd.isna(x): return np.nan
    s=str(x).strip()
    # Works whether API returns "POLICY_CODE" or "POLICY_CODE: Label".
    return s.split(":",1)[0].strip()

def label_text(x):
    if pd.isna(x): return ""
    s=str(x)
    return s.split(":",1)[1].strip() if ":" in s else s

def find_col(df,name):
    for c in df.columns:
        if str(c).split(":",1)[0].strip().upper()==name.upper():
            return c
    return None

def parse_month(s):
    s=s.astype("string").str.strip()
    # IMF commonly returns 2018-M01; also accept 2018-01.
    s=s.str.replace(r"^(\d{4})-M(\d{2})$",r"\1-\2",regex=True)
    tok=s.str.extract(r"^(\d{4}-\d{2})",expand=False)
    return pd.to_datetime(tok+"-01",errors="coerce")

def imf_data_url(agency,flow,key,start,end):
    return (f"{BASE}/data/dataflow/{agency}/{flow}/~/{key}"
            f"?c[TIME_PERIOD]=ge:{start}&c[TIME_PERIOD]=le:{end}")

def download_cpi(countries,start,end,raw):
    # Current CPI DSD key:
    # COUNTRY.INDEX_TYPE.COICOP.TYPE_OF_TRANSFORMATION.FREQUENCY
    key=f"{'+'.join(countries)}.CPI._T.IX.M"
    url=imf_data_url("IMF.STA","CPI",key,start,end)
    df,text=read_csv_url(url)
    (raw/"imf_cpi_raw.csv").write_text(text,encoding="utf-8")
    c_country=find_col(df,"COUNTRY"); c_time=find_col(df,"TIME_PERIOD"); c_val=find_col(df,"OBS_VALUE")
    if not all([c_country,c_time,c_val]):
        raise KeyError(f"Unexpected CPI columns: {list(df.columns)}")
    z=pd.DataFrame({
      "country":df[c_country].map(machine_code),
      "year_month":parse_month(df[c_time]),
      "imf_cpi_index":pd.to_numeric(df[c_val],errors="coerce")
    }).dropna(subset=["country","year_month"])
    z=z[z.country.isin(countries)].groupby(["country","year_month"],as_index=False).imf_cpi_index.last()
    z=z.sort_values(["country","year_month"])
    z["imf_inflation_mom_pct"]=z.groupby("country").imf_cpi_index.transform(lambda x:100*np.log(x).diff())
    z["imf_inflation_yoy_pct"]=z.groupby("country").imf_cpi_index.transform(lambda x:100*np.log(x).diff(12))
    return z,url

def download_rates(countries,start,end,raw):
    # Current MFS_IR DSD: COUNTRY.INDICATOR.FREQUENCY
    key=f"{'+'.join(countries)}.*.M"
    url=imf_data_url("IMF.STA","MFS_IR",key,start,end)
    df,text=read_csv_url(url)
    (raw/"imf_mfs_ir_raw.csv").write_text(text,encoding="utf-8")
    cc=find_col(df,"COUNTRY"); ci=find_col(df,"INDICATOR"); ct=find_col(df,"TIME_PERIOD"); cv=find_col(df,"OBS_VALUE")
    if not all([cc,ci,ct,cv]):
        raise KeyError(f"Unexpected MFS_IR columns: {list(df.columns)}")
    z=pd.DataFrame({
      "country":df[cc].map(machine_code),
      "indicator_code":df[ci].map(machine_code),
      "indicator_raw":df[ci].astype(str),
      "indicator_label":df[ci].map(label_text),
      "year_month":parse_month(df[ct]),
      "value":pd.to_numeric(df[cv],errors="coerce")
    }).dropna(subset=["country","year_month"])
    z=z[z.country.isin(countries)]
    return z,url

def score_rate_series(code,label):
    text=(str(code)+" "+str(label)).lower()
    # Explicit monetary-policy instruments first.
    positive=[
      (100,r"monetary policy|policy rate|policy interest|official rate|official interest"),
      (90,r"central bank.*rate|bank rate|target rate|target interest"),
      (85,r"refinanc|repo rate|discount rate|rediscount"),
      (60,r"interbank"),
      (50,r"money.?market")
    ]
    score=0; reason=""
    for pts,pat in positive:
        if re.search(pat,text):
            score=max(score,pts)
            if score==pts: reason=pat
    # Avoid obviously wrong rates.
    if re.search(r"deposit.*household|lending.*household|mortgage|government bond|treasury bill|saving",text):
        score-=100
    return score,reason

def select_rate(z,start,end):
    audits=[]; chosen=[]
    for country,g in z.groupby("country"):
        cand=(g.groupby(["indicator_code","indicator_label"],dropna=False)
              .agg(n=("value","count"),first=("year_month","min"),last=("year_month","max"))
              .reset_index())
        scored=[]
        for _,r in cand.iterrows():
            sc,why=score_rate_series(r.indicator_code,r.indicator_label)
            scored.append((sc,why))
        cand["score"]=[x[0] for x in scored]; cand["match_rule"]=[x[1] for x in scored]
        cand["country"]=country
        cand=cand.sort_values(["score","n"],ascending=[False,False])
        audits.append(cand)
        if len(cand) and cand.iloc[0].score>0:
            best=cand.iloc[0]
            q=g[g.indicator_code.eq(best.indicator_code)].copy()
            q=q.groupby(["country","year_month"],as_index=False).value.last()
            q=q.rename(columns={"value":"imf_policy_or_proxy_rate_pct"})
            q["imf_rate_indicator_code"]=best.indicator_code
            q["imf_rate_indicator_label"]=best.indicator_label
            q["imf_rate_selection_score"]=best.score
            q["imf_rate_is_proxy"]=(best.score<80).astype(int) if hasattr(best.score,"astype") else int(best.score<80)
            chosen.append(q)
    audit=pd.concat(audits,ignore_index=True) if audits else pd.DataFrame()
    out=pd.concat(chosen,ignore_index=True) if chosen else pd.DataFrame(
        columns=["country","year_month","imf_policy_or_proxy_rate_pct","imf_rate_indicator_code",
                 "imf_rate_indicator_label","imf_rate_selection_score","imf_rate_is_proxy"])
    if not out.empty:
        out=out.sort_values(["country","year_month"])
        out["imf_d_policy_or_proxy_rate_pp"]=out.groupby("country").imf_policy_or_proxy_rate_pct.diff()
    return out,audit

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--start",default="2018-01")
    ap.add_argument("--end",default="2025-12")
    ap.add_argument("--output",default="macro_phase3_imf")
    ap.add_argument("--all-latam",action="store_true")
    a=ap.parse_args()
    countries=list(LATAM18) if a.all_latam else MISSING
    root=Path(a.output); raw=root/"data_raw"; proc=root/"data_processed"; meta=root/"metadata"
    for p in [raw,proc,meta]: p.mkdir(parents=True,exist_ok=True)
    log=[]

    print("Countries:",", ".join(countries))
    print("\nDownloading IMF monthly CPI...")
    try:
        cpi,cpiurl=download_cpi(countries,a.start,a.end,raw)
        cpi.to_csv(proc/"imf_cpi_monthly.csv",index=False)
        print(f"  OK: {len(cpi):,} country-month rows; {cpi.country.nunique()} countries")
        log.append(["CPI","OK",len(cpi),cpi.country.nunique(),cpiurl,""])
    except Exception as e:
        print("  FAILED:",e); cpi=pd.DataFrame()
        log.append(["CPI","ERROR",0,0,"",str(e)])

    print("\nDownloading IMF MFS interest-rate universe...")
    try:
        rates,rateurl=download_rates(countries,a.start,a.end,raw)
        rates.to_csv(raw/"imf_mfs_ir_tidy_all_candidates.csv",index=False)
        selected,audit=select_rate(rates,a.start,a.end)
        audit.to_csv(meta/"interest_rate_candidate_audit.csv",index=False)
        selected.to_csv(proc/"imf_selected_policy_or_proxy_rate_monthly.csv",index=False)
        print(f"  OK: {len(rates):,} raw monthly rate observations")
        print(f"  Auto-selected a policy/proxy series for {selected.country.nunique() if len(selected) else 0} countries")
        log.append(["MFS_IR","OK",len(rates),selected.country.nunique() if len(selected) else 0,rateurl,""])
    except Exception as e:
        print("  FAILED:",e); selected=pd.DataFrame()
        log.append(["MFS_IR","ERROR",0,0,"",str(e)])

    months=pd.date_range(pd.Timestamp(a.start+"-01"),pd.Timestamp(a.end+"-01"),freq="MS")
    grid=pd.MultiIndex.from_product([countries,months],names=["country","year_month"]).to_frame(index=False)
    grid["country_name"]=grid.country.map(LATAM18)
    if not cpi.empty: grid=grid.merge(cpi,on=["country","year_month"],how="left")
    if not selected.empty: grid=grid.merge(selected,on=["country","year_month"],how="left")
    grid.to_csv(proc/"phase3_imf_country_month.csv",index=False)

    cov=[]
    for country,g in grid.groupby("country"):
        cov.append({
          "country":country,
          "cpi_pct":100*g.get("imf_cpi_index",pd.Series(index=g.index,dtype=float)).notna().mean(),
          "inflation_yoy_pct_coverage":100*g.get("imf_inflation_yoy_pct",pd.Series(index=g.index,dtype=float)).notna().mean(),
          "rate_pct":100*g.get("imf_policy_or_proxy_rate_pct",pd.Series(index=g.index,dtype=float)).notna().mean(),
          "rate_proxy_flag":g.get("imf_rate_is_proxy",pd.Series(index=g.index,dtype=float)).dropna().max()
        })
    pd.DataFrame(cov).to_csv(meta/"coverage_by_country.csv",index=False)
    pd.DataFrame(log,columns=["dataset","status","rows","countries","url","message"]).to_csv(meta/"download_log.csv",index=False)

    print("\nDone.")
    print("Main file:",proc/"phase3_imf_country_month.csv")
    print("IMPORTANT: inspect metadata/interest_rate_candidate_audit.csv.")
    print("A rate with imf_rate_is_proxy=1 is NOT an official policy rate and must be labelled as a proxy.")
    print("Do not interpret missing policy rates for dollarized countries as zero.")

if __name__=="__main__":
    main()
