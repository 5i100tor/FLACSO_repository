#!/usr/bin/env python3
"""Corrected IMF WEO debt/GDP downloader (SDMX 3.0, Oct 2026)."""
from pathlib import Path
import os, time, json, requests, pandas as pd

START_YEAR, END_YEAR = 2018, 2025
BASE="https://api.imf.org/external/sdmx/3.0"
INDICATOR="GGXWDG_NGDP"
LATAM18={"ARG":"Argentina","BOL":"Bolivia","BRA":"Brazil","CHL":"Chile","COL":"Colombia","CRI":"Costa Rica","DOM":"Dominican Republic","ECU":"Ecuador","SLV":"El Salvador","GTM":"Guatemala","HND":"Honduras","MEX":"Mexico","NIC":"Nicaragua","PAN":"Panama","PRY":"Paraguay","PER":"Peru","URY":"Uruguay","VEN":"Venezuela"}
ADVANCED8={"USA":"United States","CAN":"Canada","GBR":"United Kingdom","DEU":"Germany","FRA":"France","ITA":"Italy","ESP":"Spain","JPN":"Japan"}
COUNTRIES={**LATAM18,**ADVANCED8}
OUT=Path("imf_weo_debt_gdp_26countries_sdmx")
for p in [OUT/"data",OUT/"metadata",OUT/"raw"]: p.mkdir(parents=True,exist_ok=True)

# Optional .env key. Public access is tried first if none is present.
if Path('.env').exists():
    for line in Path('.env').read_text().splitlines():
        if '=' in line and not line.strip().startswith('#'):
            k,v=line.split('=',1); os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))
key=os.getenv('IMF_SDMX_SUBSCRIPTION_KEY') or os.getenv('IMF_API_PRIMARY_KEY') or os.getenv('IMF_API_KEY')
headers={"User-Agent":"Mozilla/5.0","Accept":"application/vnd.sdmx.data+json;version=2.0.0, application/json"}
if key: headers['Ocp-Apim-Subscription-Key']=key
S=requests.Session(); S.headers.update(headers)

def fetch(iso):
    # Current WEO dimension order is COUNTRY.INDICATOR.FREQUENCY.
    url=f"{BASE}/data/dataflow/IMF.RES/WEO/9.0.0/{iso}.{INDICATOR}.A"
    params={'startPeriod':str(START_YEAR),'endPeriod':str(END_YEAR)}
    last=None
    for a in range(5):
        try:
            r=S.get(url,params=params,timeout=60); r.raise_for_status(); js=r.json()
            (OUT/'raw'/f'{iso}.json').write_text(json.dumps(js,indent=2))
            return js
        except Exception as e:
            last=e; print(f'  attempt {a+1}/5: {e}'); time.sleep(min(2**(a+1),10))
    raise RuntimeError(last)

def parse(js):
    # IMF SDMX-JSON: decode observation time labels from structures.
    dsets=js.get('dataSets',[])
    structs=js.get('structures',[])
    if not dsets or not structs: raise ValueError('Unexpected SDMX JSON shape')
    st=structs[0]; ds=dsets[0]
    odims=st.get('dimensions',{}).get('observation',[])
    tvals=[]
    for dim in odims:
        if dim.get('id') in ('TIME_PERIOD','TIME'):
            tvals=[v.get('id') or v.get('name') for v in dim.get('values',[])]
            break
    if not tvals: raise ValueError('TIME_PERIOD dimension not found')
    out={}
    series=ds.get('series',{})
    containers=list(series.values()) if isinstance(series,dict) else []
    if not containers and 'observations' in ds: containers=[ds]
    for ser in containers:
        for idx,val in ser.get('observations',{}).items():
            i=int(str(idx).split(':')[0]); v=val[0] if isinstance(val,list) else val
            if i<len(tvals) and v is not None: out[int(str(tvals[i])[:4])]=float(v)
    if not out: raise ValueError('No observations parsed')
    return out

rows=[]; failures=[]
for n,(iso,name) in enumerate(COUNTRIES.items(),1):
    print(f'[{n:02d}/26] {iso} {name}')
    try: vals=parse(fetch(iso))
    except Exception as e:
        print('  FAILED:',e); failures.append({'country':iso,'error':str(e)}); vals={}
    for y in range(START_YEAR,END_YEAR+1):
        rows.append({'country':iso,'country_name':name,'year':y,'x_general_gov_gross_debt_pct_gdp':vals.get(y),'x_debt_source':'IMF WEO SDMX 3.0 / GGXWDG_NGDP','x_latam':int(iso in LATAM18),'x_advanced_economy':int(iso in ADVANCED8)})
    time.sleep(.15)
annual=pd.DataFrame(rows)
for t in [10,25,50,75,100]:
    c=f'x_debt_gdp_ge_{t}'; annual[c]=(annual.x_general_gov_gross_debt_pct_gdp>=t).astype('Int64'); annual.loc[annual.x_general_gov_gross_debt_pct_gdp.isna(),c]=pd.NA
annual_path=OUT/'data'/'imf_weo_general_government_gross_debt_pct_gdp_2018_2025.csv'; annual.to_csv(annual_path,index=False)
monthly=annual.loc[annual.index.repeat(12)].copy(); monthly['month']=monthly.groupby(['country','year']).cumcount()+1; monthly['year_month']=pd.to_datetime(dict(year=monthly.year,month=monthly.month,day=1)).dt.strftime('%Y-%m-%d'); monthly.drop(columns='month',inplace=True)
monthly_path=OUT/'data'/'imf_weo_general_government_gross_debt_pct_gdp_monthly_2018_2025.csv'; monthly.to_csv(monthly_path,index=False)
cov=annual.groupby(['country','country_name'],as_index=False).agg(years_with_debt=('x_general_gov_gross_debt_pct_gdp','count'),min_debt_pct_gdp=('x_general_gov_gross_debt_pct_gdp','min'),max_debt_pct_gdp=('x_general_gov_gross_debt_pct_gdp','max'),mean_debt_pct_gdp=('x_general_gov_gross_debt_pct_gdp','mean')); cov['coverage_pct']=100*cov.years_with_debt/8; cov.to_csv(OUT/'metadata'/'coverage.csv',index=False)
pd.DataFrame(failures).to_csv(OUT/'metadata'/'failures.csv',index=False)
(OUT/'README.txt').write_text('IMF WEO SDMX 3.0; GGXWDG_NGDP; 2018-2025; monthly file repeats annual values; no interpolation. Threshold flags >=10/25/50/75/100%.')
print('\nDONE\n',cov.to_string(index=False)); print('\nAnnual:',annual_path); print('Monthly:',monthly_path)
if failures: print('WARNING: failures recorded in metadata/failures.csv')
