#!/usr/bin/env python3
"""
download_macro_phase2_v4.py
Phase 2 v4 — BIS domestic monetary controls + no-key BTC/ETH controls.

Validated against the current BIS bulk CSV schema (headers AND coded cell values
such as "M: Monthly", "AR: Argentina", "628: Index, 2010 = 100").

Outputs: macro_phase2_v4/
"""

import argparse, io, json, re, time, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
import requests

BIS = {
 "fx":"https://data.bis.org/static/bulk/WS_XRU_csv_flat.zip",
 "cpi":"https://data.bis.org/static/bulk/WS_LONG_CPI_csv_flat.zip",
 "policy":"https://data.bis.org/static/bulk/WS_CBPOL_csv_flat.zip",
}
LATAM18 = {
 "ARG":("AR","Argentina"),"BOL":("BO","Bolivia"),"BRA":("BR","Brazil"),
 "CHL":("CL","Chile"),"COL":("CO","Colombia"),"CRI":("CR","Costa Rica"),
 "DOM":("DO","Dominican Republic"),"ECU":("EC","Ecuador"),
 "SLV":("SV","El Salvador"),"GTM":("GT","Guatemala"),"HND":("HN","Honduras"),
 "MEX":("MX","Mexico"),"NIC":("NI","Nicaragua"),"PAN":("PA","Panama"),
 "PRY":("PY","Paraguay"),"PER":("PE","Peru"),"URY":("UY","Uruguay"),
 "VEN":("VE","Venezuela")
}
USD_REGIME={"ECU","SLV","PAN"}
HEADERS={"User-Agent":"academic-stablecoin-macro-research/4.0"}

def code(x):
    """Machine code before ':' in current BIS labels."""
    if pd.isna(x): return np.nan
    return str(x).split(":",1)[0].strip()

def getcol(df, code_name):
    for c in df.columns:
        if str(c).split(":",1)[0].strip().upper()==code_name.upper():
            return c
    raise KeyError(f"{code_name} not found. Columns={list(df.columns)}")

def fetch(url, params=None, retries=4):
    err=None
    for i in range(retries):
        try:
            r=requests.get(url,params=params,headers=HEADERS,timeout=180)
            r.raise_for_status(); return r.content
        except Exception as e:
            err=e; time.sleep(2*(i+1))
    raise RuntimeError(f"{url}: {err}")

def bis_df(kind, raw):
    b=fetch(BIS[kind]); (raw/f"bis_{kind}_bulk.zip").write_bytes(b)
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        name=[n for n in z.namelist() if n.lower().endswith(".csv")][0]
        with z.open(name) as f: return pd.read_csv(f,low_memory=False)

def standardize(df):
    """Add machine-readable dimension columns without destroying source labels."""
    out=df.copy()
    for nm in ["FREQ","REF_AREA","CURRENCY","COLLECTION","UNIT_MEASURE"]:
        try:
            c=getcol(out,nm); out[f"_{nm}"]=out[c].map(code)
        except KeyError: pass
    t=getcol(out,"TIME_PERIOD"); v=getcol(out,"OBS_VALUE")
    out["_TIME"]=out[t].astype("string").str.strip()
    out["_VALUE"]=pd.to_numeric(out[v],errors="coerce")
    return out

def month_from_period(s):
    s=s.astype("string").str.strip()
    tok=s.str.extract(r"^(\d{4}(?:-\d{2}(?:-\d{2})?)?)",expand=False)
    tok=tok.mask(tok.str.fullmatch(r"\d{4}",na=False),tok+"-01-01")
    tok=tok.mask(tok.str.fullmatch(r"\d{4}-\d{2}",na=False),tok+"-01")
    return pd.to_datetime(tok,errors="coerce").dt.to_period("M").dt.to_timestamp()

def date_from_period(s):
    return pd.to_datetime(s.astype("string").str.extract(r"^(\d{4}-\d{2}-\d{2})",expand=False),
                          errors="coerce")

def bounds(start,end):
    return pd.Timestamp(start).to_period("M").start_time, pd.Timestamp(end).to_period("M").start_time

def process_fx(df,start,end):
    x=standardize(df)
    map2={v[0]:k for k,v in LATAM18.items()}
    x=x[x["_REF_AREA"].isin(map2)].copy()
    x["country"]=x["_REF_AREA"].map(map2)
    lo,hi=bounds(start,end)

    # Monthly EOP is the clean primary level.
    m=x[(x["_FREQ"]=="M")&(x["_COLLECTION"]=="E")].copy()
    m["year_month"]=month_from_period(m["_TIME"])
    m=m[(m.year_month>=lo)&(m.year_month<=hi)]
    m=(m.sort_values("_TIME").groupby(["country","year_month"],as_index=False)["_VALUE"].last()
       .rename(columns={"_VALUE":"fx_lcu_per_usd_eop"}))

    # Daily data provide EOM fallback and within-month realized FX volatility.
    d=x[x["_FREQ"]=="D"].copy()
    d["date"]=date_from_period(d["_TIME"])
    d=d[(d.date>=pd.Timestamp(start))&(d.date<=pd.Timestamp(end))]
    d=d.sort_values(["country","date"])
    d["year_month"]=d.date.dt.to_period("M").dt.to_timestamp()
    d["dlog"]=d.groupby("country")["_VALUE"].transform(lambda z:np.log(z).diff())
    dg=d.groupby(["country","year_month"],as_index=False).agg(
        fx_daily_eom=("_VALUE","last"),fx_daily_mean=("_VALUE","mean"),
        fx_vol_daily_log_sd=("dlog","std"),fx_daily_n=("_VALUE","count"))
    dg["fx_vol_daily_log_sd_pct"]=100*dg["fx_vol_daily_log_sd"]
    dg=dg.drop(columns="fx_vol_daily_log_sd")

    out=m.merge(dg,on=["country","year_month"],how="outer")
    out["fx_lcu_per_usd_eop"]=out["fx_lcu_per_usd_eop"].fillna(out["fx_daily_eom"])

    # Complete grid and transparent USD-regime fallback.
    months=pd.date_range(lo,hi,freq="MS")
    grid=pd.MultiIndex.from_product([LATAM18,months],names=["country","year_month"]).to_frame(index=False)
    out=grid.merge(out,on=["country","year_month"],how="left")
    imp=out.country.isin(USD_REGIME)&out.fx_lcu_per_usd_eop.isna()
    out.loc[imp,"fx_lcu_per_usd_eop"]=1.0
    out["fx_imputed_usd_regime"]=imp.astype(int)
    out=out.sort_values(["country","year_month"])
    out["fx_depreciation_mom_pct"]=out.groupby("country")["fx_lcu_per_usd_eop"].transform(lambda z:100*np.log(z).diff())
    out["fx_depreciation_yoy_pct"]=out.groupby("country")["fx_lcu_per_usd_eop"].transform(lambda z:100*np.log(z).diff(12))
    return out

def process_cpi(df,start,end):
    x=standardize(df)
    map2={v[0]:k for k,v in LATAM18.items()}
    x=x[(x["_REF_AREA"].isin(map2))&(x["_FREQ"]=="M")].copy()
    x["country"]=x["_REF_AREA"].map(map2)
    x["year_month"]=month_from_period(x["_TIME"])
    lo,hi=bounds(start,end); x=x[(x.year_month>=lo)&(x.year_month<=hi)]

    # BIS has both index (628) and direct YoY % change (771).
    idx=x[x["_UNIT_MEASURE"]=="628"].copy()
    idx=(idx.groupby(["country","year_month"],as_index=False)["_VALUE"].last()
         .rename(columns={"_VALUE":"cpi_index"}))
    yoy=x[x["_UNIT_MEASURE"]=="771"].copy()
    yoy=(yoy.groupby(["country","year_month"],as_index=False)["_VALUE"].last()
         .rename(columns={"_VALUE":"inflation_yoy_bis_pct"}))
    out=idx.merge(yoy,on=["country","year_month"],how="outer").sort_values(["country","year_month"])
    out["inflation_mom_pct"]=out.groupby("country")["cpi_index"].transform(lambda z:100*np.log(z).diff())
    out["inflation_yoy_from_index_pct"]=out.groupby("country")["cpi_index"].transform(lambda z:100*np.log(z).diff(12))
    # Prefer BIS direct YoY; use index-derived where direct series is absent.
    out["inflation_yoy_pct"]=out["inflation_yoy_bis_pct"].fillna(out["inflation_yoy_from_index_pct"])
    return out

def process_policy(df,start,end):
    x=standardize(df)
    map2={v[0]:k for k,v in LATAM18.items()}
    x=x[x["_REF_AREA"].isin(map2)].copy(); x["country"]=x["_REF_AREA"].map(map2)
    lo,hi=bounds(start,end)

    m=x[x["_FREQ"]=="M"].copy()
    m["year_month"]=month_from_period(m["_TIME"]); m=m[(m.year_month>=lo)&(m.year_month<=hi)]
    m=(m.groupby(["country","year_month"],as_index=False)["_VALUE"].last()
       .rename(columns={"_VALUE":"policy_rate_pct"}))

    d=x[x["_FREQ"]=="D"].copy(); d["date"]=date_from_period(d["_TIME"])
    d=d[(d.date>=pd.Timestamp(start))&(d.date<=pd.Timestamp(end))]
    d["year_month"]=d.date.dt.to_period("M").dt.to_timestamp()
    de=(d.sort_values("date").groupby(["country","year_month"],as_index=False)["_VALUE"].last()
        .rename(columns={"_VALUE":"policy_rate_daily_eom_pct"}))
    out=m.merge(de,on=["country","year_month"],how="outer")
    out["policy_rate_pct"]=out["policy_rate_pct"].fillna(out["policy_rate_daily_eom_pct"])
    out=out.sort_values(["country","year_month"])
    out["d_policy_rate_pp"]=out.groupby("country")["policy_rate_pct"].diff()
    return out

def yahoo_daily(symbol,start,end):
    p1=int(pd.Timestamp(start,tz="UTC").timestamp())
    p2=int((pd.Timestamp(end,tz="UTC")+pd.Timedelta(days=1)).timestamp())
    params={"period1":p1,"period2":p2,"interval":"1d","events":"history","includeAdjustedClose":"true"}
    last=None
    for host in ["query1.finance.yahoo.com","query2.finance.yahoo.com"]:
        try:
            js=json.loads(fetch(f"https://{host}/v8/finance/chart/{symbol}",params).decode())
            r=js["chart"]["result"][0]; ts=r["timestamp"]; q=r["indicators"]["quote"][0]
            return pd.DataFrame({"date":pd.to_datetime(ts,unit="s",utc=True).tz_convert(None),
                "open":q["open"],"high":q["high"],"low":q["low"],"close":q["close"],"volume":q["volume"]})
        except Exception as e: last=e
    raise RuntimeError(last)

def crypto(raw,start,end):
    pieces=[]
    for sym,prefix in [("BTC-USD","bitcoin"),("ETH-USD","ethereum")]:
        d=yahoo_daily(sym,start,end); d.to_csv(raw/f"yahoo_{prefix}_daily.csv",index=False)
        d=d.sort_values("date"); d["year_month"]=d.date.dt.to_period("M").dt.to_timestamp()
        d["logret"]=np.log(d.close).diff()
        m=d.groupby("year_month").agg(price_usd_mean=("close","mean"),price_usd_eom=("close","last"),
             volume_units_mean=("volume","mean"),volume_units_sum=("volume","sum"),
             daily_logret_sd=("logret","std"),daily_obs=("close","count")).reset_index()
        m["return_mom_pct"]=100*np.log(m.price_usd_eom).diff()
        m["realized_volatility_pct"]=100*m.daily_logret_sd; m=m.drop(columns="daily_logret_sd")
        m=m.rename(columns={c:f"{prefix}_{c}" for c in m if c!="year_month"}); pieces.append(m)
    return pieces[0].merge(pieces[1],on="year_month",how="outer")

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--start",default="2018-01-01")
    ap.add_argument("--end",default="2025-12-31"); ap.add_argument("--output",default="macro_phase2_v4")
    a=ap.parse_args(); root=Path(a.output); raw=root/"data_raw"; proc=root/"data_processed"; meta=root/"metadata"
    for p in [raw,proc,meta]: p.mkdir(parents=True,exist_ok=True)
    log=[]; datasets={}
    for kind,fn in [("fx",process_fx),("cpi",process_cpi),("policy",process_policy)]:
        print(f"Downloading BIS {kind}...")
        try:
            z=fn(bis_df(kind,raw),a.start,a.end); z.to_csv(proc/f"bis_{kind}_monthly.csv",index=False)
            datasets[kind]=z
            nonmiss=int(z.drop(columns=["country","year_month"],errors="ignore").notna().any(axis=1).sum())
            print(f"  OK: {len(z):,} rows; rows with data: {nonmiss:,}")
            log.append(["BIS",kind,"OK",len(z),nonmiss,""])
        except Exception as e:
            print("  FAILED:",e); log.append(["BIS",kind,"ERROR",0,0,str(e)])

    print("Downloading BTC/ETH from Yahoo Finance (no key)...")
    try:
        cr=crypto(raw,a.start,a.end); cr.to_csv(proc/"crypto_monthly.csv",index=False)
        print(f"  OK: {len(cr)} months"); log.append(["Yahoo","BTC_ETH","OK",len(cr),len(cr),""])
    except Exception as e:
        cr=pd.DataFrame(); print("  FAILED:",e); log.append(["Yahoo","BTC_ETH","ERROR",0,0,str(e)])

    lo,hi=bounds(a.start,a.end); months=pd.date_range(lo,hi,freq="MS")
    panel=pd.MultiIndex.from_product([LATAM18,months],names=["country","year_month"]).to_frame(index=False)
    panel["country_name"]=panel.country.map({k:v[1] for k,v in LATAM18.items()})
    for z in datasets.values(): panel=panel.merge(z,on=["country","year_month"],how="left")
    if not cr.empty: panel=panel.merge(cr,on="year_month",how="left")
    panel.to_csv(proc/"phase2_country_month.csv",index=False)

    cov=[]
    for c in panel.columns:
        if c not in ["country","country_name","year_month"]:
            for k,g in panel.groupby("country"):
                cov.append([k,c,g[c].notna().sum(),len(g),100*g[c].notna().mean()])
    pd.DataFrame(cov,columns=["country","variable","n_nonmissing","n_months","coverage_pct"]).to_csv(meta/"coverage_report.csv",index=False)
    pd.DataFrame(log,columns=["source","dataset","status","rows","rows_with_data","message"]).to_csv(meta/"download_log.csv",index=False)

    print(f"\nDone: {proc/'phase2_country_month.csv'}")
    print("Rows:",len(panel))
    print("Expected rows: 1,728")
    print("IMPORTANT: inspect metadata/coverage_report.csv before regression use.")

if __name__=="__main__": main()
