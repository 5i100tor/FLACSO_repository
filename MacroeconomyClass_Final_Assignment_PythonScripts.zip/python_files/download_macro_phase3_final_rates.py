#!/usr/bin/env python3
"""
download_macro_phase3_final_rates.py

Final IMF interest-rate pass for the LATAM countries not covered by BIS.

What changed:
- Uses the actual IMF MFS_IR indicator codes found in the user's Phase-3 download.
- MFS166_RT_PT_A_PT = policy/central-bank rate (preferred).
- MMRT_RT_PT_A_PT   = money-market rate (proxy).
- DISR_RT_PT_A_PT   = discount rate (fallback proxy).
- Does NOT substitute deposit/lending rates for monetary-policy rates.
- Does NOT invent a rate for dollarized ECU/SLV/PAN.
- Saves all three candidate series plus one transparent "best available" series.

Source: IMF.STA/MFS_IR, monthly, percent per annum.
Default sample: 2018-01 to 2025-12.
"""

import argparse, io, time
from pathlib import Path
import numpy as np
import pandas as pd
import requests

BASE="https://api.imf.org/external/sdmx/3.0"
HEADERS={"Accept":"text/csv","User-Agent":"academic-stablecoin-macro-research/final-rates"}

COUNTRIES={
 "BOL":"Bolivia","CRI":"Costa Rica","DOM":"Dominican Republic","ECU":"Ecuador",
 "SLV":"El Salvador","GTM":"Guatemala","HND":"Honduras","NIC":"Nicaragua",
 "PAN":"Panama","PRY":"Paraguay","URY":"Uruguay","VEN":"Venezuela"
}
DOLLARIZED={"ECU","SLV","PAN"}

INDICATORS={
 "MFS166_RT_PT_A_PT":("policy_rate","official_policy_or_central_bank_rate",1),
 "MMRT_RT_PT_A_PT":("money_market_rate","money_market_proxy",2),
 "DISR_RT_PT_A_PT":("discount_rate","discount_rate_proxy",3),
}

def fetch(url,retries=4):
    last=None
    for i in range(retries):
        try:
            r=requests.get(url,headers=HEADERS,timeout=180)
            r.raise_for_status()
            if not r.text.strip(): raise RuntimeError("empty response")
            return r
        except Exception as e:
            last=e; time.sleep(2*(i+1))
    raise RuntimeError(last)

def find_col(df,name):
    for c in df.columns:
        if str(c).split(":",1)[0].strip().upper()==name.upper(): return c
    raise KeyError(f"{name} not found; columns={list(df.columns)}")

def parse_month(s):
    s=s.astype("string").str.strip().str.replace(r"^(\d{4})-M(\d{2})$",r"\1-\2",regex=True)
    return pd.to_datetime(s.str.extract(r"^(\d{4}-\d{2})",expand=False)+"-01",errors="coerce")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--start",default="2018-01")
    ap.add_argument("--end",default="2025-12")
    ap.add_argument("--output",default="macro_phase3_final_rates")
    a=ap.parse_args()

    root=Path(a.output); raw=root/"data_raw"; proc=root/"data_processed"; meta=root/"metadata"
    for p in [raw,proc,meta]: p.mkdir(parents=True,exist_ok=True)

    country_key="+".join(COUNTRIES)
    indicator_key="+".join(INDICATORS)
    url=(f"{BASE}/data/dataflow/IMF.STA/MFS_IR/~/{country_key}.{indicator_key}.M"
         f"?c[TIME_PERIOD]=ge:{a.start}&c[TIME_PERIOD]=le:{a.end}")

    print("Downloading explicit IMF monetary-rate indicators...")
    r=fetch(url)
    (raw/"imf_selected_rate_indicators_raw.csv").write_text(r.text,encoding="utf-8")
    d=pd.read_csv(io.StringIO(r.text),low_memory=False)

    cc=find_col(d,"COUNTRY"); ci=find_col(d,"INDICATOR")
    ct=find_col(d,"TIME_PERIOD"); cv=find_col(d,"OBS_VALUE")
    x=pd.DataFrame({
        "country":d[cc].astype(str).str.split(":").str[0].str.strip(),
        "indicator":d[ci].astype(str).str.split(":").str[0].str.strip(),
        "year_month":parse_month(d[ct]),
        "value":pd.to_numeric(d[cv],errors="coerce")
    }).dropna(subset=["country","year_month"])
    x=x[x.country.isin(COUNTRIES)&x.indicator.isin(INDICATORS)].copy()

    # Long candidate file.
    x["series_type"]=x.indicator.map(lambda z:INDICATORS[z][0])
    x["interpretation"]=x.indicator.map(lambda z:INDICATORS[z][1])
    x["priority"]=x.indicator.map(lambda z:INDICATORS[z][2])
    x.to_csv(proc/"imf_rate_candidates_long.csv",index=False)

    # Wide file: keep each concept separately.
    wide=x.pivot_table(index=["country","year_month"],columns="series_type",
                       values="value",aggfunc="last").reset_index()
    wide.columns.name=None

    months=pd.date_range(a.start+"-01",a.end+"-01",freq="MS")
    grid=pd.MultiIndex.from_product([COUNTRIES,months],
                                    names=["country","year_month"]).to_frame(index=False)
    grid["country_name"]=grid.country.map(COUNTRIES)
    wide=grid.merge(wide,on=["country","year_month"],how="left")

    for c in ["policy_rate","money_market_rate","discount_rate"]:
        if c not in wide: wide[c]=np.nan

    # Best available monetary-policy stance measure.
    # For dollarized economies: intentionally missing.
    wide["monetary_rate_best_pct"]=np.nan
    wide["monetary_rate_source"]="missing"

    non_dollar=~wide.country.isin(DOLLARIZED)
    m=non_dollar & wide.policy_rate.notna()
    wide.loc[m,"monetary_rate_best_pct"]=wide.loc[m,"policy_rate"]
    wide.loc[m,"monetary_rate_source"]="IMF policy/central-bank rate"

    m=non_dollar & wide.monetary_rate_best_pct.isna() & wide.money_market_rate.notna()
    wide.loc[m,"monetary_rate_best_pct"]=wide.loc[m,"money_market_rate"]
    wide.loc[m,"monetary_rate_source"]="IMF money-market proxy"

    m=non_dollar & wide.monetary_rate_best_pct.isna() & wide.discount_rate.notna()
    wide.loc[m,"monetary_rate_best_pct"]=wide.loc[m,"discount_rate"]
    wide.loc[m,"monetary_rate_source"]="IMF discount-rate proxy"

    wide.loc[wide.country.isin(DOLLARIZED),"monetary_rate_source"]="not applicable: dollarized economy"
    wide["monetary_rate_is_proxy"]=wide.monetary_rate_source.str.contains("proxy",case=False).astype(int)
    wide["d_monetary_rate_pp"]=wide.groupby("country").monetary_rate_best_pct.diff()
    wide.to_csv(proc/"phase3_final_monetary_rates.csv",index=False)

    # Coverage/audit.
    cov=[]
    for c,g in wide.groupby("country"):
        cov.append({
            "country":c,
            "country_name":COUNTRIES[c],
            "policy_rate_months":int(g.policy_rate.notna().sum()),
            "money_market_months":int(g.money_market_rate.notna().sum()),
            "discount_rate_months":int(g.discount_rate.notna().sum()),
            "best_rate_months":int(g.monetary_rate_best_pct.notna().sum()),
            "best_rate_coverage_pct":round(100*g.monetary_rate_best_pct.notna().mean(),1),
            "dollarized":int(c in DOLLARIZED),
            "note":("No independent domestic policy rate expected" if c in DOLLARIZED else
                    "Keep missing if IMF has no defensible policy/MM/discount series")
        })
    cov=pd.DataFrame(cov)
    cov.to_csv(meta/"coverage_and_audit.csv",index=False)

    print("\nCoverage:")
    print(cov[["country","policy_rate_months","money_market_months",
               "discount_rate_months","best_rate_months","dollarized"]].to_string(index=False))
    print("\nDone:",proc/"phase3_final_monetary_rates.csv")
    print("\nInterpretation rules:")
    print("  policy rate > money-market proxy > discount-rate proxy")
    print("  ECU/SLV/PAN remain NA by design.")
    print("  NIC/VEN may remain sparse/missing; do NOT replace with deposit/lending rates.")

if __name__=="__main__":
    main()
