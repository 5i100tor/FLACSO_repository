#!/usr/bin/env python3
"""
download_external_debt_extension_v2.py

Repair/extension downloader for two gaps from v1:
  A) IDS currency composition of long-term external PPG debt (explicit source=6).
  B) QEDS observations, using the official World Bank bulk CSV file rather than
     per-indicator API calls.

This script does NOT modify the stablecoin master or the v1 output.
Target window: 2018-2024 (QEDS: 2018Q1-2024Q4).
"""

from pathlib import Path
import io, re, time, zipfile
import pandas as pd
import requests

OUT = Path("external_debt_download_v2")
OUT.mkdir(exist_ok=True)
LATAM = ["ARG","BOL","BRA","CHL","COL","CRI","DOM","ECU","SLV","GTM","HND",
         "MEX","NIC","PAN","PRY","PER","URY","VEN"]
CC = ";".join(LATAM)
S = requests.Session()
S.headers.update({"User-Agent":"Mozilla/5.0 stablecoin-research/2.0"})
LOG=[]

def log(x):
    print(x); LOG.append(str(x))

def get(url, params=None, tries=5, timeout=120):
    err=None
    for k in range(tries):
        try:
            r=S.get(url,params=params,timeout=timeout)
            r.raise_for_status()
            return r
        except Exception as e:
            err=e
            log(f"retry {k+1}/{tries}: {e}")
            time.sleep(2**k)
    raise RuntimeError(f"FAILED {url}: {err}")

# ============================================================
# A. IDS CURRENCY COMPOSITION -- EXPLICIT IDS SOURCE 6
# ============================================================
CUR = {
 "DT.CUR.USDL.ZS":"ppg_currency_share_usd_pct",
 "DT.CUR.EURO.ZS":"ppg_currency_share_euro_pct",
 "DT.CUR.JYEN.ZS":"ppg_currency_share_jpy_pct",
 "DT.CUR.UKPS.ZS":"ppg_currency_share_gbp_pct",
 "DT.CUR.SDRW.ZS":"ppg_currency_share_sdr_pct",
 "DT.CUR.MULC.ZS":"ppg_currency_share_multiple_pct",
 "DT.CUR.OTHC.ZS":"ppg_currency_share_other_pct",
 "DT.CUR.SWFR.ZS":"ppg_currency_share_chf_pct",
}
cur=[]
for code,alias in CUR.items():
    log(f"IDS source=6: {code}")
    url=f"https://api.worldbank.org/v2/country/{CC}/indicator/{code}"
    try:
        j=get(url,{"format":"json","source":"6","date":"2018:2024","per_page":20000}).json()
        if isinstance(j,list) and len(j)>1 and j[1]:
            for x in j[1]:
                cur.append({"country":x.get("countryiso3code"),
                            "country_name":(x.get("country") or {}).get("value"),
                            "year":pd.to_numeric(x.get("date"),errors="coerce"),
                            "indicator":code,"variable":alias,"value":x.get("value")})
    except Exception as e:
        log(f"ERROR {code}: {e}")

cdf=pd.DataFrame(cur)
if not cdf.empty:
    cdf=cdf[cdf.country.isin(LATAM)]
    cdf.to_csv(OUT/"ids_currency_composition_raw_long_2018_2024.csv",index=False)
    cw=cdf.pivot_table(index=["country","country_name","year"],columns="variable",
                       values="value",aggfunc="first").reset_index()
    cw.columns.name=None
    cw.to_csv(OUT/"ids_currency_composition_wide_2018_2024.csv",index=False)
    cov=[]
    for c in LATAM:
        for v in CUR.values():
            z=cw[(cw.country==c)&cw.get(v,pd.Series(index=cw.index,dtype=float)).notna()] if v in cw else pd.DataFrame()
            cov.append([c,v,len(z),z.year.min() if len(z) else None,z.year.max() if len(z) else None])
    pd.DataFrame(cov,columns=["country","variable","n_nonmissing","first_year","last_year"]).to_csv(
        OUT/"ids_currency_coverage.csv",index=False)
else:
    log("WARNING: explicit IDS API still returned no currency-composition observations.")

# ============================================================
# B. QEDS -- OFFICIAL WORLD BANK BULK CSV
# ============================================================
# Official QEDS SDDS bulk CSV link from World Bank Data Catalog.
QEDS_SDDS_CSV = "https://datacatalogfiles.worldbank.org/ddh-published/0037740/DR0045613/SDDS_CSV.zip"

log("Downloading official QEDS SDDS bulk CSV (~76 MB)...")
try:
    raw=get(QEDS_SDDS_CSV,timeout=300).content
    (OUT/"SDDS_CSV.zip").write_bytes(raw)
    z=zipfile.ZipFile(io.BytesIO(raw))
    names=z.namelist()
    pd.DataFrame({"zip_member":names}).to_csv(OUT/"qeds_bulk_zip_inventory.csv",index=False)
    log(f"QEDS ZIP downloaded; {len(names)} members.")

    # Inspect all CSVs and identify data files. World Bank bulk files commonly
    # contain a main data CSV plus metadata/country/series CSVs.
    summaries=[]
    candidates=[]
    for name in names:
        if name.lower().endswith(".csv") and not name.startswith("__MACOSX"):
            try:
                with z.open(name) as f:
                    sample=pd.read_csv(f,nrows=5,low_memory=False)
                cols=list(sample.columns)
                summaries.append({"file":name,"columns":" | ".join(map(str,cols)),
                                  "n_sample_cols":len(cols)})
                low=" ".join(map(str,cols)).lower()
                if any(k in low for k in ["country","series","indicator","time","year","quarter"]):
                    candidates.append(name)
            except Exception as e:
                summaries.append({"file":name,"columns":f"READ_ERROR {e}","n_sample_cols":0})
    pd.DataFrame(summaries).to_csv(OUT/"qeds_bulk_csv_inventory.csv",index=False)

    # Extract candidate CSVs locally for transparent inspection/validation.
    exdir=OUT/"qeds_bulk_extracted"; exdir.mkdir(exist_ok=True)
    for name in candidates:
        target=exdir/Path(name).name
        with z.open(name) as src, open(target,"wb") as dst:
            dst.write(src.read())

    # Try to identify a conventional World Bank bulk data table.
    # Typical shape: Country Name, Country Code, Series Name, Series Code,
    # then quarterly columns such as 2018Q1 [YR2018Q1].
    data_frames=[]
    for p in exdir.glob("*.csv"):
        try:
            d=pd.read_csv(p,low_memory=False)
        except Exception:
            continue
        cols=[str(c) for c in d.columns]
        country_code=next((c for c in cols if c.lower() in ["country code","country_code","economy code"]),None)
        series_code=next((c for c in cols if c.lower() in ["series code","series_code","indicator code"]),None)
        series_name=next((c for c in cols if c.lower() in ["series name","series_name","indicator name"]),None)
        country_name=next((c for c in cols if c.lower() in ["country name","country_name","economy"]),None)
        qcols=[c for c in cols if re.search(r"20(18|19|20|21|22|23|24).*Q[1-4]|Q[1-4].*20(18|19|20|21|22|23|24)",c,re.I)]
        if country_code and series_code and qcols:
            x=d[d[country_code].astype(str).isin(LATAM)].copy()
            if len(x):
                idcols=[c for c in [country_name,country_code,series_name,series_code] if c]
                m=x[idcols+qcols].melt(id_vars=idcols,var_name="period_raw",value_name="value")
                m["period"]=m.period_raw.astype(str).str.extract(r"(20(?:18|19|20|21|22|23|24).*?Q[1-4]|20(?:18|19|20|21|22|23|24)Q[1-4])",expand=False)
                m["period"]=m["period"].str.replace(r"[^0-9Q]","",regex=True).str[:6]
                m=m.rename(columns={country_code:"country",series_code:"series_id"})
                if country_name: m=m.rename(columns={country_name:"country_name"})
                if series_name: m=m.rename(columns={series_name:"series_name"})
                m["source_file"]=p.name
                data_frames.append(m)

    if data_frames:
        qraw=pd.concat(data_frames,ignore_index=True).drop_duplicates()
        qraw["value"]=pd.to_numeric(qraw["value"].replace({"..":None,"":None}),errors="coerce")
        qraw=qraw[qraw.country.isin(LATAM) & qraw.period.str.match(r"^20(18|19|20|21|22|23|24)Q[1-4]$",na=False)]
        qraw.to_csv(OUT/"qeds_LATAM18_raw_long_2018Q1_2024Q4.csv",index=False)

        # Select analytically useful stock series from their labels.
        sn=qraw.get("series_name",pd.Series("",index=qraw.index)).fillna("").str.lower()
        useful = (
            sn.str.contains("gross ext") &
            ~sn.str.contains("pmt|payment|principal|interest") &
            sn.str.contains(r"short.?term|one year or less|all maturit",regex=True)
        )
        qu=qraw[useful].copy()
        qu.to_csv(OUT/"qeds_LATAM18_shortterm_candidates_2018Q1_2024Q4.csv",index=False)

        qc=(qu.assign(nonmissing=qu.value.notna())
             .groupby(["series_id","series_name","country"],dropna=False)
             .agg(n_nonmissing=("nonmissing","sum"),
                  first_period=("period","min"),last_period=("period","max"))
             .reset_index())
        qc.to_csv(OUT/"qeds_LATAM18_shortterm_coverage.csv",index=False)

        # Separate keyword subsets useful for the final variable choice.
        for label,pat in {
            "general_government":r"general government",
            "banks":r"deposit.?taking|bank",
            "central_bank":r"central bank",
            "other_sectors":r"other sectors",
            "all_sectors":r"all sectors",
            "foreign_currency":r"foreign currency|u\.s\. dollar|usd",
        }.items():
            sub=qu[qu.series_name.fillna("").str.contains(pat,case=False,regex=True)]
            sub.to_csv(OUT/f"qeds_candidates_{label}.csv",index=False)
        log(f"Parsed QEDS LATAM rows={len(qraw):,}; short-term candidate rows={len(qu):,}.")
    else:
        log("WARNING: bulk ZIP downloaded, but automatic parser did not identify the main data table.")
        log("Upload the whole v2 folder: the extracted CSVs and inventory will let us map its exact schema.")

except Exception as e:
    log(f"QEDS BULK ERROR: {e}")

(OUT/"README.txt").write_text("""V2 repair download for the external-debt extension.

A) IDS currency composition:
   Explicitly requests World Bank International Debt Statistics source 6.

B) QEDS:
   Downloads the official World Bank QEDS SDDS bulk CSV ZIP rather than using
   the per-indicator API route that returned zero observations in v1.
   It preserves the raw bulk ZIP and extracted files, and attempts to create
   LATAM18 long-format files for 2018Q1-2024Q4.

Do NOT merge with the stablecoin master yet.
Please ZIP the entire external_debt_download_v2 folder and upload it for validation.
""",encoding="utf-8")
(OUT/"download_log.txt").write_text("\n".join(LOG),encoding="utf-8")
print("\nDONE. Zip external_debt_download_v2 and upload it.")
