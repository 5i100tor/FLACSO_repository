#!/usr/bin/env python3
"""
download_macro_panel.py

Builds a reproducible macro-data layer for the stablecoin project.

Outputs:
  data_raw/world_bank_annual.csv
  data_raw/fred_daily.csv
  data_raw/fred_monthly.csv
  data_processed/global_financial_monthly.csv
  data_processed/world_bank_annual.csv
  data_processed/macro_monthly_scaffold.csv
  metadata/series_dictionary.csv
  metadata/download_log.csv

Coverage:
  LATAM18 + optional comparison economies.
  2018-2025 by default.

Sources implemented in this first robust version:
  1) World Bank Indicators API (no key required)
  2) FRED API (key required)

Why not silently interpolate annual/quarterly macro variables?
  This downloader preserves source frequency. Annual WDI values are merged onto a
  monthly scaffold as year-level controls, clearly labelled. You can later decide
  whether to carry forward, interpolate, or use mixed-frequency models.

Install:
  python -m pip install pandas numpy requests python-dotenv

FRED:
  Create a free FRED API key and either:
    export FRED_API_KEY="your_key"
  or create a .env file next to this script:
    FRED_API_KEY=your_key

Run:
  python download_macro_panel.py

Optional:
  python download_macro_panel.py --start 2018-01-01 --end 2025-12-31 --core-only
"""

from __future__ import annotations
import argparse
import os
import time
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import requests

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

WB_BASE = "https://api.worldbank.org/v2"
FRED_BASE = "https://api.stlouisfed.org/fred/series/observations"

LATAM18 = {
    "ARG":"Argentina","BOL":"Bolivia","BRA":"Brazil","CHL":"Chile",
    "COL":"Colombia","CRI":"Costa Rica","DOM":"Dominican Republic",
    "ECU":"Ecuador","SLV":"El Salvador","GTM":"Guatemala","HND":"Honduras",
    "MEX":"Mexico","NIC":"Nicaragua","PAN":"Panama","PRY":"Paraguay",
    "PER":"Peru","URY":"Uruguay","VEN":"Venezuela",
}

COMPARISON = {
    "USA":"United States","CAN":"Canada","CHN":"China","JPN":"Japan",
    "IND":"India","RUS":"Russia","GBR":"United Kingdom","DEU":"Germany",
    "FRA":"France","ITA":"Italy","ESP":"Spain",
}

# Annual WDI variables. These are useful for scale/structure and lower-frequency controls.
WB_INDICATORS: Dict[str, str] = {
    "SP.POP.TOTL": "population",
    "NY.GDP.MKTP.CD": "gdp_current_usd",
    "NY.GDP.PCAP.CD": "gdp_per_capita_current_usd",
    "NY.GDP.MKTP.KD.ZG": "real_gdp_growth_pct",
    "FP.CPI.TOTL.ZG": "inflation_cpi_annual_pct",
    "BN.CAB.XOKA.GD.ZS": "current_account_pct_gdp",
    "NE.TRD.GNFS.ZS": "trade_openness_pct_gdp",
    "BX.TRF.PWKR.DT.GD.ZS": "remittances_received_pct_gdp",
    "BX.TRF.PWKR.CD.DT": "remittances_received_usd",
    "FI.RES.TOTL.CD": "total_reserves_including_gold_usd",
    "FI.RES.XGLD.CD": "total_reserves_excluding_gold_usd",
    "NE.EXP.GNFS.CD": "exports_goods_services_usd",
    "NE.IMP.GNFS.CD": "imports_goods_services_usd",
}

# FRED global controls. DGS series are daily market yields.
FRED_SERIES: Dict[str, str] = {
    "DFF": "fed_funds_effective_pct",
    "DGS2": "us_treasury_2y_pct",
    "DGS10": "us_treasury_10y_pct",
    "VIXCLS": "vix",
    "DTWEXBGS": "broad_usd_index",
}

HEADERS = {"User-Agent": "stablecoin-macro-research/1.0"}

def get_json(url, params=None, retries=4, timeout=45):
    last = None
    for i in range(retries):
        try:
            r = requests.get(url, params=params, headers=HEADERS, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            last = e
            time.sleep(1.5 * (i + 1))
    raise RuntimeError(f"Request failed after {retries} tries: {url}\n{last}")

def wb_download(countries: Dict[str,str], start_year: int, end_year: int):
    rows, log = [], []
    country_string = ";".join(countries.keys())
    for indicator, var in WB_INDICATORS.items():
        url = f"{WB_BASE}/country/{country_string}/indicator/{indicator}"
        params = {
            "date": f"{start_year}:{end_year}",
            "format": "json",
            "per_page": 20000,
        }
        try:
            js = get_json(url, params)
            obs = js[1] if isinstance(js, list) and len(js) > 1 and js[1] else []
            n = 0
            for x in obs:
                iso3 = x.get("countryiso3code")
                if iso3 not in countries:
                    continue
                rows.append({
                    "country": iso3,
                    "country_name": countries[iso3],
                    "year": int(x["date"]),
                    "indicator_code": indicator,
                    "variable": var,
                    "value": pd.to_numeric(x.get("value"), errors="coerce"),
                })
                n += 1
            log.append(["World Bank", indicator, var, "OK", n, ""])
        except Exception as e:
            log.append(["World Bank", indicator, var, "ERROR", 0, str(e)])
    return pd.DataFrame(rows), log

def fred_download(api_key: str, start: str, end: str):
    frames, log = [], []
    if not api_key:
        for sid, var in FRED_SERIES.items():
            log.append(["FRED", sid, var, "SKIPPED", 0, "FRED_API_KEY not set"])
        return pd.DataFrame(), log

    for sid, var in FRED_SERIES.items():
        params = {
            "series_id": sid,
            "api_key": api_key,
            "file_type": "json",
            "observation_start": start,
            "observation_end": end,
        }
        try:
            js = get_json(FRED_BASE, params)
            x = pd.DataFrame(js["observations"])[["date","value"]]
            x["date"] = pd.to_datetime(x["date"])
            x[var] = pd.to_numeric(x["value"], errors="coerce")
            x = x[["date",var]]
            frames.append(x)
            log.append(["FRED", sid, var, "OK", x[var].notna().sum(), ""])
        except Exception as e:
            log.append(["FRED", sid, var, "ERROR", 0, str(e)])

    if not frames:
        return pd.DataFrame(), log

    daily = frames[0]
    for x in frames[1:]:
        daily = daily.merge(x, on="date", how="outer")
    return daily.sort_values("date"), log

def monthly_from_daily(daily: pd.DataFrame):
    if daily.empty:
        return daily
    x = daily.set_index("date").sort_index()
    # Mean monthly level plus end-of-month level and within-month volatility.
    out = pd.DataFrame(index=x.resample("MS").mean().index)
    for c in x.columns:
        out[c + "_mean"] = x[c].resample("MS").mean()
        out[c + "_eom"] = x[c].resample("MS").last()
        out[c + "_sd"] = x[c].resample("MS").std()
    out.index.name = "year_month"
    out = out.reset_index()

    # Economically useful derived global controls.
    if "us_treasury_10y_pct_mean" in out and "us_treasury_2y_pct_mean" in out:
        out["us_10y_minus_2y_pp"] = (
            out["us_treasury_10y_pct_mean"] - out["us_treasury_2y_pct_mean"]
        )
    if "us_treasury_2y_pct_mean" in out:
        out["d_us_2y_pp"] = out["us_treasury_2y_pct_mean"].diff()
    if "us_treasury_10y_pct_mean" in out:
        out["d_us_10y_pp"] = out["us_treasury_10y_pct_mean"].diff()
    if "broad_usd_index_mean" in out:
        out["dlog_broad_usd_pct"] = 100 * np.log(out["broad_usd_index_mean"]).diff()
    return out

def pivot_wb(raw: pd.DataFrame):
    if raw.empty:
        return raw
    return (
        raw.pivot_table(index=["country","country_name","year"],
                        columns="variable", values="value", aggfunc="first")
           .reset_index()
           .rename_axis(None, axis=1)
    )

def make_monthly_scaffold(countries, start, end, wb_wide, fred_monthly):
    months = pd.date_range(pd.Timestamp(start).to_period("M").start_time,
                           pd.Timestamp(end).to_period("M").start_time, freq="MS")
    base = pd.MultiIndex.from_product(
        [list(countries.keys()), months], names=["country","year_month"]
    ).to_frame(index=False)
    base["country_name"] = base["country"].map(countries)
    base["year"] = base["year_month"].dt.year

    # Annual WDI controls repeated within year, explicitly retaining their annual origin.
    if not wb_wide.empty:
        base = base.merge(wb_wide, on=["country","country_name","year"], how="left")

    # Global controls are identical across countries in a given month.
    if not fred_monthly.empty:
        base = base.merge(fred_monthly, on="year_month", how="left")
    return base

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--start", default="2018-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--core-only", action="store_true",
                   help="Download only LATAM18, not comparison economies.")
    p.add_argument("--output", default="macro_api_download")
    args = p.parse_args()

    start_year, end_year = pd.Timestamp(args.start).year, pd.Timestamp(args.end).year
    countries = dict(LATAM18)
    if not args.core_only:
        countries.update(COMPARISON)

    root = Path(args.output)
    rawdir, procdir, metadir = root/"data_raw", root/"data_processed", root/"metadata"
    for q in (rawdir, procdir, metadir):
        q.mkdir(parents=True, exist_ok=True)

    logs = []

    print(f"Downloading World Bank data for {len(countries)} countries...")
    wb_raw, l = wb_download(countries, start_year, end_year)
    logs += l
    wb_raw.to_csv(rawdir/"world_bank_annual.csv", index=False)
    wb_wide = pivot_wb(wb_raw)
    wb_wide.to_csv(procdir/"world_bank_annual.csv", index=False)

    print("Downloading FRED global financial variables...")
    fred_key = os.getenv("FRED_API_KEY", "").strip()
    fred_daily, l = fred_download(fred_key, args.start, args.end)
    logs += l
    if not fred_daily.empty:
        fred_daily.to_csv(rawdir/"fred_daily.csv", index=False)
    fred_monthly = monthly_from_daily(fred_daily)
    if not fred_monthly.empty:
        fred_monthly.to_csv(procdir/"global_financial_monthly.csv", index=False)

    print("Building monthly country scaffold...")
    panel = make_monthly_scaffold(
        countries, args.start, args.end, wb_wide, fred_monthly
    )
    panel.to_csv(procdir/"macro_monthly_scaffold.csv", index=False)

    dictionary = []
    for code,var in WB_INDICATORS.items():
        dictionary.append(["World Bank", code, var, "annual",
                           "Country-specific WDI series"])
    for code,var in FRED_SERIES.items():
        dictionary.append(["FRED", code, var, "daily",
                           "Global financial control; monthly mean/EOM/SD derived"])
    pd.DataFrame(dictionary, columns=[
        "source","series_code","variable","source_frequency","notes"
    ]).to_csv(metadir/"series_dictionary.csv", index=False)

    pd.DataFrame(logs, columns=[
        "source","series_code","variable","status","n_observations","message"
    ]).to_csv(metadir/"download_log.csv", index=False)

    print("\nDone.")
    print(f"Main scaffold: {procdir/'macro_monthly_scaffold.csv'}")
    print(f"Rows: {len(panel):,}")
    print("IMPORTANT: WDI variables retain annual source frequency.")
    if not fred_key:
        print("FRED was skipped because FRED_API_KEY is not set.")

if __name__ == "__main__":
    main()
