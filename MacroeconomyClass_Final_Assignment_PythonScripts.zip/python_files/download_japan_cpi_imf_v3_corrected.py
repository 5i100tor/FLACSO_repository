#!/usr/bin/env python3
"""
Japan CPI from the CURRENT IMF SDMX 3.0 API — corrected direct query.

The IMF CPI dataflow's documented key order is:
    COUNTRY.INDICATOR.TYPE_OF_TRANSFORMATION.INDEX_TYPE.FREQUENCY

For Japan all-items CPI index, monthly:
    JPN.CPI._T.IX.M

Important correction from the previous script:
- use the actual CPI key instead of a broad wildcard query
- use "~" for latest version (with "+" fallback)
- use SDMX component TIME_PERIOD filters
- request CSV explicitly
"""

import argparse, io, time
from pathlib import Path
import pandas as pd
import requests

BASE="https://api.imf.org/external/sdmx/3.0"
KEY="JPN.CPI._T.IX.M"
UA={"User-Agent":"MacroEcon1 academic research/1.0"}

def fetch(url, attempts=4):
    headers={"User-Agent":UA["User-Agent"],
             "Accept":"text/csv, application/vnd.sdmx.data+csv;version=2.0.0"}
    last=None
    for n in range(attempts):
        try:
            # IMF SDMX 3.0 supports component filters.
            params=[
                ("c[TIME_PERIOD]","ge:2017-M01"),
                ("c[TIME_PERIOD]","le:2025-M12"),
            ]
            r=requests.get(url,params=params,headers=headers,timeout=(20,120))
            if r.status_code in (429,500,502,503,504):
                raise requests.HTTPError(f"HTTP {r.status_code}",response=r)
            r.raise_for_status()
            return r
        except Exception as e:
            last=e
            if n<attempts-1:
                wait=2**n
                print(f"    retry {n+1}/{attempts}: {e}; sleeping {wait}s")
                time.sleep(wait)
    raise last

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--out",default="imf_japan_cpi_v3")
    a=ap.parse_args()
    out=Path(a.out); data=out/"data"; meta=out/"metadata"; raw=out/"raw"
    for p in (data,meta,raw): p.mkdir(parents=True,exist_ok=True)

    errors=[]
    response=None

    # "~" is used by the current IMF examples for latest; "+" retained as fallback.
    for version in ("~","+"):
        url=f"{BASE}/data/dataflow/IMF.STA/CPI/{version}/{KEY}"
        print("Trying:",url)
        try:
            r=fetch(url)
            (raw/f"response_{'latest' if version=='~' else 'plus'}.txt").write_text(
                r.text, encoding="utf-8"
            )
            if not r.text.strip():
                raise RuntimeError("empty response")
            # CSV should have COUNTRY,TIME_PERIOD,OBS_VALUE (possibly additional cols)
            df=pd.read_csv(io.StringIO(r.text))
            if "TIME_PERIOD" not in df.columns or "OBS_VALUE" not in df.columns:
                raise RuntimeError(f"Unexpected columns: {list(df.columns)}")
            if len(df)==0:
                raise RuntimeError("zero observations")
            response=(df,r.url,version)
            break
        except Exception as e:
            errors.append(f"{version}: {type(e).__name__}: {e}")
            print("    failed:",errors[-1])

    if response is None:
        (meta/"diagnostics.txt").write_text("\n".join(errors))
        raise RuntimeError(
            "The corrected IMF CPI query still returned no usable data. "
            "See metadata/diagnostics.txt. Do not keep retrying blindly."
        )

    df,url,version=response
    df.to_csv(data/"JPN_IMF_CPI_raw.csv",index=False)

    # Strictly validate requested series.
    if "COUNTRY" in df.columns:
        df=df[df["COUNTRY"].astype(str).str.upper().isin(["JPN","JP","JAPAN"])]
    if "FREQUENCY" in df.columns:
        df=df[df["FREQUENCY"].astype(str).str.upper().eq("M")]

    q=pd.DataFrame({
        "year_month":pd.to_datetime(
            df["TIME_PERIOD"].astype(str).str.replace("-M","-",regex=False),
            errors="coerce"
        ).dt.to_period("M").dt.to_timestamp(),
        "cpi_index":pd.to_numeric(df["OBS_VALUE"],errors="coerce")
    }).dropna()

    q=q[(q.year_month>=pd.Timestamp("2017-01-01")) &
        (q.year_month<=pd.Timestamp("2025-12-01"))].copy()

    # Duplicates are only acceptable if the numeric CPI is identical.
    check=q.groupby("year_month").cpi_index.agg(["min","max","count"])
    ambiguous=check[(check["max"]-check["min"]).abs()>1e-9]
    if len(ambiguous):
        raise RuntimeError(
            f"IMF returned conflicting CPI values in {len(ambiguous)} months; "
            "raw data saved, no automatic selection made."
        )
    q=q.groupby("year_month",as_index=False).cpi_index.mean().sort_values("year_month")

    # Exact calendar-year lag, not row shift.
    lag=q[["year_month","cpi_index"]].rename(
        columns={"cpi_index":"cpi_index_12m_ago"}).copy()
    lag["year_month"]=lag["year_month"]+pd.DateOffset(years=1)
    q=q.merge(lag,on="year_month",how="left")
    q["inflation_yoy_pct"]=100*(q["cpi_index"]/q["cpi_index_12m_ago"]-1)
    q["source"]="IMF.STA CPI, current SDMX 3.0 API"
    q["series_key"]=KEY
    q.to_csv(data/"JPN_IMF_CPI_monthly_2017_2025.csv",index=False)

    final=q[(q.year_month>=pd.Timestamp("2018-01-01")) &
            (q.year_month<=pd.Timestamp("2025-12-01"))].copy()
    final.to_csv(data/"JPN_IMF_inflation_monthly_2018_2025.csv",index=False)

    n_cpi=int(final.cpi_index.notna().sum())
    n_inf=int(final.inflation_yoy_pct.notna().sum())
    diag=[
        f"Successful version selector: {version}",
        f"Series key: {KEY}",
        f"Resolved URL: {url}",
        f"CPI coverage 2018-2025: {n_cpi}/96",
        f"YoY inflation coverage 2018-2025: {n_inf}/96",
        "YoY formula: 100*(CPI_t/CPI_t-12 - 1)",
        "Interpolation: none",
    ]
    (meta/"diagnostics.txt").write_text("\n".join(diag))
    print("\nSUCCESS")
    print("\n".join(diag))
    if n_inf < 90:
        print("\nWARNING: coverage is incomplete. Do not merge blindly.")

if __name__=="__main__":
    main()
