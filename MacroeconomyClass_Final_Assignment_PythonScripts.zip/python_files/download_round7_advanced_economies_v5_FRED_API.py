#!/usr/bin/env python3
"""
Round 7 downloader/builder: Advanced-economy benchmark for stablecoin analysis.

TARGET ADVANCED ECONOMIES
USA, Canada, United Kingdom, Germany, France, Italy, Spain, Japan
Period: Jan-2018 to Dec-2025.

WHAT THIS SCRIPT DOES
1. Reads the existing Reuter stablecoin ZIP and extracts the 8 advanced economies.
2. Downloads monthly CPI inflation from the official OECD SDMX API.
3. Downloads daily USD FX rates and policy rates from the official FRED API using the API key in .env.
4. Builds monthly FX levels, MoM/YoY depreciation and daily-within-month FX volatility.
5. Merges annual World Bank/global variables from the user's existing Phase-1 macro scaffold
   if supplied.
6. Produces a clean advanced-economy monthly panel and a validation/coverage report.

IMPORTANT DESIGN CHOICES
- Stablecoin variables use exactly the same construction as the LATAM work:
  inflows, outflows, gross=in+out, net=in-out, holdings.
- EUR countries share the same EUR/USD market rate by construction; this is correct.
- USA has no domestic USD/USD depreciation, so FX depreciation/volatility are set to 0 and
  explicitly flagged as structural zeros.
- Policy rate: Fed funds (USA), BoC, BoE, ECB deposit facility for euro-area members,
  BoJ policy-related short rate proxy from FRED where available.
- No interpolation of missing macro observations.
- Output retains source columns/flags for reproducibility.

USAGE
python3 download_round7_advanced_economies.py \
  --stablecoin-zip stablecoin_flows_holdings.zip \
  --phase1-csv macro_monthly_scaffold.csv

If --phase1-csv is omitted, the script still builds the stablecoin + monthly macro panel.
"""

import argparse, io, json, time, zipfile, shutil, random, os
from pathlib import Path
import numpy as np
import pandas as pd
import requests

START="2018-01-01"; END="2025-12-31"
ADV={
 "USA":"United States","CAN":"Canada","GBR":"United Kingdom","DEU":"Germany",
 "FRA":"France","ITA":"Italy","ESP":"Spain","JPN":"Japan"
}
# Reuter country-name aliases: script resolves these flexibly.
ALIASES={
 "USA":["United States","United States of America","USA"],
 "CAN":["Canada"],
 "GBR":["United Kingdom","UK","Great Britain"],
 "DEU":["Germany"],
 "FRA":["France"],
 "ITA":["Italy"],
 "ESP":["Spain"],
 "JPN":["Japan"]
}
OECD={"USA":"USA","CAN":"CAN","GBR":"GBR","DEU":"DEU","FRA":"FRA","ITA":"ITA","ESP":"ESP","JPN":"JPN"}

# FRED USD exchange-rate series. Units differ; transformed below so x_fx_usd_per_lcu
# always means USD per local-currency unit.
FX_FRED={
 "CAN":("DEXCAUS","CAD per USD","invert"),
 "GBR":("DEXUSUK","USD per GBP","direct"),
 "DEU":("DEXUSEU","USD per EUR","direct"),
 "FRA":("DEXUSEU","USD per EUR","direct"),
 "ITA":("DEXUSEU","USD per EUR","direct"),
 "ESP":("DEXUSEU","USD per EUR","direct"),
 "JPN":("DEXJPUS","JPY per USD","invert"),
}
# FRED policy-rate series. Missing series do not abort the build.
POLICY_FRED={
 "USA":"DFF",       # effective federal funds rate
 "CAN":"IRSTCI01CAM156N", # short-term/policy-related monthly rate fallback
 "GBR":"IUDERB6",   # Bank Rate
 "DEU":"ECBDFR", "FRA":"ECBDFR","ITA":"ECBDFR","ESP":"ECBDFR",
 "JPN":"IRSTCI01JPM156N"
}

UA={"User-Agent":"MacroEcon1 academic research/1.0"}
CACHE_DIR=None
FRED_API_KEY=None

def load_env_key(env_path=".env"):
    """Read FRED_API_KEY from environment or a local .env file without extra dependencies."""
    key=os.getenv("FRED_API_KEY") or os.getenv("FRED_KEY")
    if key:
        return key.strip()
    p=Path(env_path)
    if p.exists():
        for raw in p.read_text().splitlines():
            line=raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k,v=line.split("=",1)
            if k.strip() in ("FRED_API_KEY","FRED_KEY"):
                return v.strip().strip('"').strip("'")
    return None

def api_get(params, attempts=5, timeout=(15,60)):
    """FRED API request with retries/backoff."""
    url="https://api.stlouisfed.org/fred/series/observations"
    last=None
    for k in range(1,attempts+1):
        try:
            with requests.Session() as s:
                r=s.get(url,params=params,headers=UA,timeout=timeout)
                if r.status_code==429 or 500 <= r.status_code < 600:
                    raise requests.HTTPError(f"HTTP {r.status_code}",response=r)
                r.raise_for_status()
                js=r.json()
                if "error_code" in js:
                    raise RuntimeError(f"FRED API error {js.get('error_code')}: {js.get('error_message')}")
                return js
        except Exception as e:
            last=e
            if k==attempts: break
            wait=min(30,2**(k-1)+random.random())
            print(f"    FRED API retry {k}/{attempts}: {type(e).__name__}; sleeping {wait:.1f}s",flush=True)
            time.sleep(wait)
    raise last

def fred(series):
    """
    Retrieve observations through the official FRED API using FRED_API_KEY.
    Successful series are cached immediately as CSV and reused on reruns.
    """
    global CACHE_DIR,FRED_API_KEY
    cache=CACHE_DIR/f"FRED_API_{series}.csv"
    if cache.exists():
        print(f"    cache hit: {series}",flush=True)
        d=pd.read_csv(cache)
        d["date"]=pd.to_datetime(d["date"],errors="coerce")
        d["value"]=pd.to_numeric(d["value"],errors="coerce")
        return d.dropna(subset=["date","value"])

    if not FRED_API_KEY:
        raise RuntimeError("No FRED API key found. Put FRED_API_KEY=... in .env or pass --env-file.")

    params={
        "series_id":series,
        "api_key":FRED_API_KEY,
        "file_type":"json",
        "observation_start":START,
        "observation_end":END
    }
    js=api_get(params)
    obs=js.get("observations",[])
    d=pd.DataFrame({
        "date":[o.get("date") for o in obs],
        "value":[o.get("value") for o in obs]
    })
    d["date"]=pd.to_datetime(d["date"],errors="coerce")
    d["value"]=pd.to_numeric(d["value"].replace(".",np.nan),errors="coerce")
    d=d.dropna(subset=["date","value"])
    d.to_csv(cache,index=False)
    time.sleep(0.35)
    return d

def find_csv(z,needle):
    hits=[n for n in z.namelist() if needle in Path(n).name.lower() and n.lower().endswith(".csv")]
    if not hits: raise FileNotFoundError(f"Cannot find {needle} CSV in ZIP")
    return hits[0]

def resolve_country_values(series):
    vals=set(series.dropna().astype(str).unique())
    out={}
    for iso,aliases in ALIASES.items():
        found=next((a for a in aliases if a in vals),None)
        if not found:
            # case-insensitive fallback
            found=next((v for v in vals if any(v.lower()==a.lower() for a in aliases)),None)
        if found: out[iso]=found
    return out

def stablecoin_panel(zip_path):
    """
    Reuter release schema:
      holdings: year_month, country (ISO3), country_name, weo_group,
                inflow, outflow, net, holdings
      flows:    year_month, country_from (ISO3), country_from_name,
                country_to (ISO3), country_to_name, value

    Use ISO3 codes directly. This avoids ambiguity in country-name matching.
    """
    with zipfile.ZipFile(zip_path) as z:
        hf=find_csv(z,"holdings")
        ff=find_csv(z,"flows")
        h=pd.read_csv(z.open(hf))
        f=pd.read_csv(z.open(ff))

    required_h={"year_month","country","holdings"}
    required_f={"year_month","country_from","country_to","value"}
    if not required_h.issubset(h.columns):
        raise RuntimeError(f"Unexpected holdings schema. Columns: {list(h.columns)}")
    if not required_f.issubset(f.columns):
        raise RuntimeError(f"Unexpected flows schema. Columns: {list(f.columns)}")

    targets=set(ADV.keys())

    # Holdings: use the actual 'holdings' column, not the first numeric column.
    hh=h[h["country"].isin(targets)].copy()
    hh["year_month"]=pd.to_datetime(hh["year_month"]).dt.to_period("M").dt.to_timestamp()
    hh=(hh.groupby(["country","year_month"],as_index=False)["holdings"]
          .sum()
          .rename(columns={"holdings":"x_holdings_usd"}))

    # Total inflows from every origin into each target economy.
    fi=f[f["country_to"].isin(targets)].copy()
    fi["country"]=fi["country_to"]
    fi["year_month"]=pd.to_datetime(fi["year_month"]).dt.to_period("M").dt.to_timestamp()
    infl=(fi.groupby(["country","year_month"])["value"]
           .sum().rename("x_inflows_usd"))

    # Total outflows from each target economy to every destination.
    fo=f[f["country_from"].isin(targets)].copy()
    fo["country"]=fo["country_from"]
    fo["year_month"]=pd.to_datetime(fo["year_month"]).dt.to_period("M").dt.to_timestamp()
    out=(fo.groupby(["country","year_month"])["value"]
          .sum().rename("x_outflows_usd"))

    idx=pd.MultiIndex.from_product(
        [ADV.keys(),pd.date_range(START,END,freq="MS")],
        names=["country","year_month"]
    )
    p=(pd.DataFrame(index=idx)
         .join(infl).join(out).reset_index()
         .merge(hh,on=["country","year_month"],how="left",validate="one_to_one"))

    p["x_inflows_usd"]=p["x_inflows_usd"].fillna(0)
    p["x_outflows_usd"]=p["x_outflows_usd"].fillna(0)
    p["x_gross_flows_usd"]=p["x_inflows_usd"]+p["x_outflows_usd"]
    p["x_net_flows_usd"]=p["x_inflows_usd"]-p["x_outflows_usd"]
    p["country_name"]=p["country"].map(ADV)

    # Verify all eight economies exist in the Reuter release.
    found=set(h.loc[h["country"].isin(targets),"country"].unique())
    missing=targets-found
    if missing:
        raise RuntimeError(f"Reuter holdings file is missing ISO3 codes: {sorted(missing)}")

    names={iso: ADV[iso] for iso in ADV}
    return p,names

def oecd_cpi():
    """
    Monthly all-items CPI YoY (%).
    First try FRED API / OECD-hosted OECD direct YoY series.
    If unavailable, download the corresponding CPI index and compute
    100*(CPI_t/CPI_t-12 - 1). No interpolation.
    """
    cc={"USA":"US","CAN":"CA","GBR":"GB","DEU":"DE",
        "FRA":"FR","ITA":"IT","ESP":"ES","JPN":"JP"}
    rows=[]
    failures={}
    for iso,c in cc.items():
        direct=f"CPALTT01{c}M659N"
        index=f"CPALTT01{c}M657N"
        done=False
        for sid,kind in [(direct,"direct_yoy"),(index,"index_derived_yoy")]:
            try:
                d=fred(sid).sort_values("date").copy()
                if kind=="index_derived_yoy":
                    d["value"]=100*(d["value"]/d["value"].shift(12)-1)
                    d=d.dropna(subset=["value"])
                d["year_month"]=d.date.dt.to_period("M").dt.to_timestamp()
                for _,r in d.iterrows():
                    rows.append([iso,r.year_month,r.value,f"FRED/OECD {sid}",kind])
                print(f"  CPI {iso}: {len(d)} obs via {sid} ({kind})",flush=True)
                done=True
                break
            except Exception as e:
                failures[f"{iso}_{sid}"]=repr(e)
                print(f"  CPI {iso}: source {sid} failed; trying fallback",flush=True)
        if not done:
            print(f"WARNING: CPI unavailable for {iso}; build will continue and flag missingness.",flush=True)
    x=pd.DataFrame(rows,columns=["country","year_month","x_inflation_yoy_pct_final","x_cpi_source","x_cpi_method"])
    if x.empty:
        print("WARNING: no CPI downloaded; continuing with empty CPI frame.",flush=True)
        x=pd.DataFrame(columns=["country","year_month","x_inflation_yoy_pct_final","x_cpi_source","x_cpi_method"])
    return x.drop_duplicates(["country","year_month"])

def build_fx():
    rows=[]
    for dt in pd.date_range(START,END,freq="MS"):
        rows.append(["USA",dt,1.0,0.0,0.0,0.0,"structural USD/USD"])
    cache={}
    for iso,(sid,unit,mode) in FX_FRED.items():
        try:
            if sid not in cache: cache[sid]=fred(sid)
            d=cache[sid].copy()
            d["rate"]=1/d.value if mode=="invert" else d.value
            d["ym"]=d.date.dt.to_period("M").dt.to_timestamp()
            n=0
            for ym,g in d.groupby("ym"):
                g=g.sort_values("date")
                eom=g.rate.iloc[-1]
                vol=100*np.log(g.rate).diff().std()
                rows.append([iso,ym,eom,np.nan,np.nan,vol,f"FRED {sid}"])
                n+=1
            print(f"  FX {iso}: {n} months ({sid})",flush=True)
        except Exception as e:
            print(f"WARNING FX {iso} {sid}: {e}",flush=True)
    x=pd.DataFrame(rows,columns=["country","year_month","x_fx_usd_per_lcu","x_fx_dep_mom_pct","x_fx_dep_yoy_pct","x_fx_volatility","x_fx_source"])
    x=x.sort_values(["country","year_month"])
    for iso in x.country.unique():
        q=x.country.eq(iso)
        if iso!="USA":
            lr=np.log(x.loc[q,"x_fx_usd_per_lcu"])
            x.loc[q,"x_fx_dep_mom_pct"]=(-100*lr.diff()).values
            x.loc[q,"x_fx_dep_yoy_pct"]=(-100*lr.diff(12)).values
    return x

def build_policy():
    rows=[]
    for iso,sid in POLICY_FRED.items():
        try:
            d=fred(sid); d["ym"]=d.date.dt.to_period("M").dt.to_timestamp()
            m=d.groupby("ym").value.mean()
            for ym,v in m.items(): rows.append([iso,ym,v,f"FRED {sid}"])
        except Exception as e:
            print("WARNING policy",iso,sid,e,flush=True)
    return pd.DataFrame(rows,columns=["country","year_month","x_policy_rate_pct","x_policy_rate_source"])

def merge_phase1(p,path):
    if not path:return p
    w=pd.read_csv(path)
    dc=next((c for c in ["country","iso3","iso3c","country_code"] if c in w.columns),None)
    tc=next((c for c in ["year_month","month","date"] if c in w.columns),None)
    if not dc or not tc:
        print("WARNING: Phase1 key columns not recognized; skipping.")
        return p
    w["country"]=w[dc].astype(str)
    w["year_month"]=pd.to_datetime(w[tc]).dt.to_period("M").dt.to_timestamp()
    keep=["country","year_month"]+[c for c in w.columns if c.startswith("x_") and c not in p.columns]
    return p.merge(w[keep].drop_duplicates(["country","year_month"]),on=["country","year_month"],how="left")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stablecoin-zip",required=True)
    ap.add_argument("--phase1-csv",default=None)
    ap.add_argument("--env-file",default=".env",help="Path to .env containing FRED_API_KEY")
    ap.add_argument("--out",default="round7_advanced_economies")
    a=ap.parse_args()
    out=Path(a.out)
    # Preserve cache across reruns. Only final data/metadata outputs are overwritten.
    out.mkdir(parents=True,exist_ok=True)
    for q in [out/"data",out/"metadata"]:q.mkdir(parents=True,exist_ok=True)
    global CACHE_DIR,FRED_API_KEY
    CACHE_DIR=out/"cache"
    CACHE_DIR.mkdir(parents=True,exist_ok=True)
    FRED_API_KEY=load_env_key(a.env_file)
    if not FRED_API_KEY:
        raise RuntimeError(f"FRED_API_KEY not found in environment or {a.env_file}")
    print("FRED API key found (value hidden).",flush=True)

    print("1/5 Extracting Reuter stablecoin panel...",flush=True)
    p,names=stablecoin_panel(Path(a.stablecoin_zip))
    print("Resolved:",names)

    print("2/5 Monthly CPI inflation (FRED/OECD)...",flush=True)
    cpi=oecd_cpi(); p=p.merge(cpi,on=["country","year_month"],how="left",validate="one_to_one")

    print("3/5 FRED FX...",flush=True)
    fx=build_fx(); p=p.merge(fx,on=["country","year_month"],how="left",validate="one_to_one")

    print("4/5 FRED policy rates...",flush=True)
    pol=build_policy(); p=p.merge(pol,on=["country","year_month"],how="left",validate="one_to_one")

    print("5/5 Merging existing Phase-1 annual/global macro variables...",flush=True)
    p=merge_phase1(p,a.phase1_csv)

    # Normalizations if GDP/population are present under likely existing names.
    gdpc=next((c for c in p.columns if c.lower() in ["x_gdp_current_usd","x_gdp_usd","gdp_current_usd","ny_gdp_mktp_cd"]),None)
    popc=next((c for c in p.columns if c.lower() in ["x_population","population","sp_pop_totl"]),None)
    if gdpc:
        p["x_gross_flows_pct_gdp"]=100*p.x_gross_flows_usd/p[gdpc]
    if popc:
        p["x_gross_flows_per_capita"]=p.x_gross_flows_usd/p[popc]

    p["x_advanced_economy"]=1
    p=p.sort_values(["country","year_month"])
    p.to_csv(out/"data"/"advanced8_stablecoin_macro_monthly_2018_2025.csv",index=False)

    key=["x_gross_flows_usd","x_holdings_usd","x_inflation_yoy_pct_final",
         "x_fx_usd_per_lcu","x_fx_dep_mom_pct","x_fx_volatility","x_policy_rate_pct"]
    cov=[]
    for iso,g in p.groupby("country"):
        for v in key:
            if v in g:
                cov.append([iso,ADV[iso],v,int(g[v].notna().sum()),len(g),100*g[v].notna().mean()])
    cv=pd.DataFrame(cov,columns=["country","country_name","variable","nonmissing","N","coverage_pct"])
    cv.to_csv(out/"metadata"/"coverage_report.csv",index=False)

    meta={
      "period":[START,END],"countries":ADV,"rows":len(p),
      "expected_rows":8*96,"duplicate_keys":int(p.duplicated(["country","year_month"]).sum()),
      "stablecoin_country_names_resolved":names,
      "sources":{
        "stablecoins":"Marco Reuter stablecoin flows/holdings ZIP supplied by user",
        "CPI":"OECD SDMX Data Explorer API, national all-items CPI YoY monthly",
        "FX":"FRED API: daily bilateral USD exchange rates",
        "policy":"FRED API / OECD-hosted central-bank/short-term policy-related rate series",
        "annual_macro":"existing Phase-1 World Bank scaffold, when supplied"
      }
    }
    (out/"metadata"/"build_metadata.json").write_text(json.dumps(meta,indent=2))
    print("\nDONE. Rows:",len(p),"duplicates:",meta["duplicate_keys"])
    print(cv.pivot(index="country",columns="variable",values="coverage_pct").round(1).to_string())
    print("\nZip and upload the entire folder:",out)

if __name__=="__main__":
    main()
