#!/usr/bin/env python3
"""
download_cpi_history_for_full_yoy.py

Downloads enough monthly CPI history to calculate YoY inflation from the very
first month of the stablecoin panel (January 2018).

Window downloaded: 2017-01 through 2025-12.
Countries: LATAM18.

Source hierarchy:
  1. BIS WS_LONG_CPI where available
  2. IMF.STA/CPI fills remaining countries/months

Outputs:
  cpi_history_2017_2025/
    data_raw/
    data_processed/LATAM18_CPI_monthly_2017_2025.csv
    data_processed/LATAM18_inflation_monthly_2018_2025.csv
    metadata/coverage_by_country.csv

No interpolation is performed.
Original BIS/IMF values are preserved alongside the consolidated x_* variables.
"""

import io, time, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
import requests

START="2017-01"
END="2025-12"
OUT=Path("cpi_history_2017_2025")
RAW=OUT/"data_raw"
PROC=OUT/"data_processed"
META=OUT/"metadata"

BIS_URL="https://data.bis.org/static/bulk/WS_LONG_CPI_csv_flat.zip"
IMF_BASE="https://api.imf.org/external/sdmx/3.0"
HEADERS={"Accept":"text/csv","User-Agent":"academic-stablecoin-macro-research/cpi-history"}

LATAM18={
 "ARG":("AR","Argentina"),"BOL":("BO","Bolivia"),"BRA":("BR","Brazil"),
 "CHL":("CL","Chile"),"COL":("CO","Colombia"),"CRI":("CR","Costa Rica"),
 "DOM":("DO","Dominican Republic"),"ECU":("EC","Ecuador"),
 "SLV":("SV","El Salvador"),"GTM":("GT","Guatemala"),"HND":("HN","Honduras"),
 "MEX":("MX","Mexico"),"NIC":("NI","Nicaragua"),"PAN":("PA","Panama"),
 "PRY":("PY","Paraguay"),"PER":("PE","Peru"),"URY":("UY","Uruguay"),
 "VEN":("VE","Venezuela")
}

def fetch(url,retries=4):
    last=None
    for i in range(retries):
        try:
            r=requests.get(url,headers=HEADERS,timeout=180)
            r.raise_for_status()
            if not r.content: raise RuntimeError("empty response")
            return r
        except Exception as e:
            last=e; time.sleep(2*(i+1))
    raise RuntimeError(f"{url}\n{last}")

def code(x):
    if pd.isna(x): return np.nan
    return str(x).split(":",1)[0].strip()

def col(df,name):
    for c in df.columns:
        if str(c).split(":",1)[0].strip().upper()==name.upper():
            return c
    raise KeyError(f"{name} not found. Columns={list(df.columns)}")

def parse_month(s):
    s=s.astype("string").str.strip()
    s=s.str.replace(r"^(\d{4})-M(\d{2})$",r"\1-\2",regex=True)
    tok=s.str.extract(r"^(\d{4}-\d{2})",expand=False)
    return pd.to_datetime(tok+"-01",errors="coerce")

def bis():
    print("Downloading BIS CPI...")
    r=fetch(BIS_URL)
    (RAW/"bis_cpi_bulk.zip").write_bytes(r.content)
    with zipfile.ZipFile(io.BytesIO(r.content)) as z:
        name=[n for n in z.namelist() if n.lower().endswith(".csv")][0]
        with z.open(name) as f:
            d=pd.read_csv(f,low_memory=False)

    cc,cf,cu,ct,cv=[col(d,x) for x in ["REF_AREA","FREQ","UNIT_MEASURE","TIME_PERIOD","OBS_VALUE"]]
    map2={v[0]:k for k,v in LATAM18.items()}
    x=pd.DataFrame({
        "country":d[cc].map(code).map(map2),
        "freq":d[cf].map(code),
        "unit":d[cu].map(code),
        "year_month":parse_month(d[ct]),
        "bis_cpi_index":pd.to_numeric(d[cv],errors="coerce")
    })
    x=x[(x.freq=="M")&(x.unit=="628")&x.country.notna()]
    x=x[(x.year_month>=pd.Timestamp("2017-01-01"))&(x.year_month<=pd.Timestamp("2025-12-01"))]
    x=x.groupby(["country","year_month"],as_index=False).bis_cpi_index.last()
    print(f"  BIS: {len(x):,} rows, {x.country.nunique()} countries")
    return x

def imf():
    print("Downloading IMF CPI...")
    countries="+".join(LATAM18)
    key=f"{countries}.CPI._T.IX.M"
    url=(f"{IMF_BASE}/data/dataflow/IMF.STA/CPI/~/{key}"
         f"?c[TIME_PERIOD]=ge:{START}&c[TIME_PERIOD]=le:{END}")
    r=fetch(url)
    (RAW/"imf_cpi_raw.csv").write_bytes(r.content)
    d=pd.read_csv(io.StringIO(r.text),low_memory=False)
    cc,ct,cv=[col(d,x) for x in ["COUNTRY","TIME_PERIOD","OBS_VALUE"]]
    x=pd.DataFrame({
        "country":d[cc].map(code),
        "year_month":parse_month(d[ct]),
        "imf_cpi_index":pd.to_numeric(d[cv],errors="coerce")
    })
    x=x[x.country.isin(LATAM18)]
    x=x.groupby(["country","year_month"],as_index=False).imf_cpi_index.last()
    print(f"  IMF: {len(x):,} rows, {x.country.nunique()} countries")
    return x

def main():
    for p in [RAW,PROC,META]: p.mkdir(parents=True,exist_ok=True)

    b=bis()
    i=imf()

    months=pd.date_range("2017-01-01","2025-12-01",freq="MS")
    grid=pd.MultiIndex.from_product([LATAM18,months],
                                    names=["country","year_month"]).to_frame(index=False)
    grid["country_name"]=grid.country.map({k:v[1] for k,v in LATAM18.items()})

    x=grid.merge(b,on=["country","year_month"],how="left")
    x=x.merge(i,on=["country","year_month"],how="left")

    # Preserve originals; x_* is consolidated.
    x["x_cpi_index"]=x.bis_cpi_index.combine_first(x.imf_cpi_index)
    x["x_cpi_source"]=np.select(
        [x.bis_cpi_index.notna(),x.imf_cpi_index.notna()],
        ["BIS","IMF"],default="missing"
    )

    x=x.sort_values(["country","year_month"])
    x["x_inflation_mom_pct"]=x.groupby("country").x_cpi_index.transform(
        lambda s:100*np.log(s).diff())
    x["x_inflation_yoy_pct"]=x.groupby("country").x_cpi_index.transform(
        lambda s:100*np.log(s).diff(12))

    x.to_csv(PROC/"LATAM18_CPI_monthly_2017_2025.csv",index=False)

    reg=x[x.year_month>=pd.Timestamp("2018-01-01")].copy()
    reg.to_csv(PROC/"LATAM18_inflation_monthly_2018_2025.csv",index=False)

    cov=[]
    for c,g in reg.groupby("country"):
        cov.append({
            "country":c,
            "cpi_months_2018_2025":int(g.x_cpi_index.notna().sum()),
            "cpi_coverage_pct":round(100*g.x_cpi_index.notna().mean(),1),
            "yoy_inflation_months_2018_2025":int(g.x_inflation_yoy_pct.notna().sum()),
            "yoy_inflation_coverage_pct":round(100*g.x_inflation_yoy_pct.notna().mean(),1),
            "jan2018_yoy_available":int(g.loc[g.year_month.eq(pd.Timestamp("2018-01-01")),
                                               "x_inflation_yoy_pct"].notna().any())
        })
    cov=pd.DataFrame(cov)
    cov.to_csv(META/"coverage_by_country.csv",index=False)

    print("\nCoverage for regression period 2018-2025:")
    print(cov.to_string(index=False))
    print("\nDone.")
    print("Regression-ready CPI/inflation:",PROC/"LATAM18_inflation_monthly_2018_2025.csv")
    print("\nGoal: Jan 2018 YoY should now be calculable wherever Dec/Jan 2017 CPI history exists.")
    print("Any remaining missing country is a genuine source-coverage issue, not an artificial sample truncation.")

if __name__=="__main__":
    main()
