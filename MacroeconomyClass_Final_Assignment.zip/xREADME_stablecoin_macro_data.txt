README — Stablecoin / Macro Analysis Data

This folder contains the two CSV files retained for the empirical
analysis of stablecoin activity, dollar scarcity, and external financial
vulnerability.

1. LATAM18_ADV8_stablecoin_macro_MASTER_FINAL_2018_2025.csv

This is the main integrated country-month panel and should be treated as
the primary dataset for reproducing the cross-country regressions in
Stata.

Coverage - Period: January 2018–December 2025 - Frequency: monthly -
Countries: 26 - 18 Latin American economies: Argentina, Bolivia, Brazil,
Chile, Colombia, Costa Rica, Dominican Republic, Ecuador, El Salvador,
Guatemala, Honduras, Mexico, Nicaragua, Panama, Paraguay, Peru, Uruguay,
Venezuela - 8 advanced economies: United States, Canada, United Kingdom,
Germany, France, Italy, Spain, Japan - Balanced panel: 2,496
country-month observations (26 × 96)

Main contents and sources - Stablecoin activity: Marco Reuter, Estimated
stablecoin flows and holdings, 2018–2025. The underlying data pool USDT
and USDC and provide monthly country-level holdings and flows. - GDP,
population, current account, trade, remittances, and international
reserves: World Bank World Development Indicators (WDI). Annual
macroeconomic variables are repeated across the months of the
corresponding year rather than interpolated. - CPI / inflation:
primarily IMF/BIS-based harmonized series used in the project; Venezuela
does not have the same complete CPI coverage as the other countries. -
Government debt/GDP: IMF World Economic Outlook (WEO),
general-government gross debt as a percentage of GDP. Annual
observations are repeated across months within each year. - US financial
conditions: FRED series for the effective Federal Funds rate, US 2-year
Treasury yield, US 10-year Treasury yield, Treasury-yield changes, the
10Y–2Y spread, VIX, and broad US-dollar measures. - Domestic FX
variables: harmonized official exchange-rate, depreciation, and
exchange-rate-volatility variables assembled during the macro-data
phases. - Parallel/shadow FX variables: country-specific parallel-market
exchange-rate data incorporated for Argentina, Bolivia, and Venezuela.
These were used to construct parallel-market premiums as indicators of
the shadow price of access to dollars. - Derived analysis variables:
gross stablecoin flows relative to GDP, log transformations, LATAM
indicators, dollarization indicators, debt thresholds, reserves/GDP,
low-reserve indicators, and convenience variables for the final
specifications. Derived variables are generally prefixed with x.

Purpose This master panel was used for the main fixed-effects analysis,
including: - inflation and stablecoin activity; - LATAM versus
advanced-economy comparisons; - formal-dollarization heterogeneity; -
debt/GDP × US2Y and debt/GDP × US10Y interactions; - LATAM-only and
LATAM-excluding-Ecuador/Panama/El Salvador robustness tests; -
reserve/GDP robustness and debt × global-financial-conditions × reserves
tests; - Argentina/Bolivia/Venezuela parallel-FX-premium analyses where
the relevant country-specific data are available.

The principal panel outcome used in the later regressions is based on
monthly gross stablecoin flows as a share of annual nominal GDP,
commonly transformed as log(1 + gross flows as % GDP).

2. Bolivia_BCB_monthly_reserves_stablecoins_2018_2025.csv

This is a specialized Bolivia time-series dataset retained separately
because it contains higher-frequency official reserve information that
is not the same as the annual cross-country reserve series in the master
panel.

Coverage - Stablecoin/inflation framework: January 2018–December 2025 -
Monthly BCB reserve observations available: January 2023–April 2025 (28
months)

Main contents and sources - rin_usd_mn: Bolivia’s international reserves
(RIN), in USD millions, from Banco Central de Bolivia (BCB) reserve data
assembled for the Bolivia case study. - rin_mom_pct: month-on-month
percentage change in reserves. - rin_yoy_pct: year-on-year percentage
change in reserves. - low_rin: derived low-reserve indicator used in the
exploratory reserve analysis. - Stablecoin outcome: Bolivia observations
from the Marco Reuter stablecoin dataset, merged to the reserve
series. - Inflation: Bolivia monthly inflation variable from the
harmonized macro panel.

Purpose This file was used for the Bolivia-specific reserve analysis
asking whether declining international reserves were associated with
increasing stablecoin activity during the recent dollar-liquidity
crisis. Those models were treated as exploratory because the usable
monthly reserve period is short and both reserves and stablecoin
activity exhibit strong trends.

The Bolivia BCB series should therefore not be confused with
total_reserves_excluding_gold_usd or x_reserves_pct_gdp in the main
master. The latter are harmonized cross-country annual WDI measures used
for panel comparisons; the BCB file provides the specialized monthly
Bolivia reserve series.

Recommended use

For a Stata replication, use
LATAM18_ADV8_stablecoin_macro_MASTER_FINAL_2018_2025.csv as the single
source of truth for the cross-country panel models. Use
Bolivia_BCB_monthly_reserves_stablecoins_2018_2025.csv only when
reproducing the specialized Bolivia monthly-reserve analysis.

The empirical results should be interpreted as associations unless a
specific event-study or matched-control design provides stronger
identification. Gross blockchain flows should not be interpreted
mechanically as resident stablecoin purchases, and reserve adequacy is
not perfectly comparable across monetary and exchange-rate regimes.
