Normalization distribution diagnostics: LATAM vs advanced economies
Source: LATAM18_ADV8_stablecoin_macro_MASTER_FINAL_2018_2025(2).csv

Construction
- Monthly gross stablecoin flows are summed within country-year.
- GDP and population are annual values from the master panel.
- Plots use each country's 2018–2025 average, weighting countries equally.
- Log axes are used because country scale differs greatly.

Median Advanced/LATAM ratios
Population: 4.56x
Nominal GDP: 34.43x
GDP per capita: 6.31x
Annual gross stablecoin flows: 6.64x
Flows per capita: 1.21x
Flows as % GDP: 0.23x

Identity
Flows / population = (Flows / GDP) * (GDP / population).

Interpretation
The advanced-country median GDP per capita is much larger than the LATAM median.
Consequently, the same flows/GDP ratio mechanically maps into much larger flows/person
in a high-GDP-per-capita country. The plots diagnose how the normalization changes the
cross-group distribution; they do not establish that GDP per capita causes the regression result.
