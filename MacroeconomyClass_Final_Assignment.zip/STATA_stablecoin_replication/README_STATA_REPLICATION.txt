STATA 16 REPLICATION PACKAGE — Stablecoins, Dollar Scarcity and External Financial Constraints

HOW TO RUN
1. Unzip this folder.
2. In Stata, change the working directory to the unzipped STATA_stablecoin_replication folder.
3. Run: do "do/09_run_all.do"
   Alternatively run the numbered files one by one in chronological order.

DO-FILE ORDER
00_setup.do
    Imports the final 26-country CSV, creates Stata country/month identifiers and convenience variables,
    and saves data/master_replication.dta.

01_baseline_inflation.do
    Baseline LATAM inflation models and outcome-normalization robustness. Includes optional boottest
    if the user-written boottest command is already installed.

02_dollarization_heterogeneity.do
    Tests inflation heterogeneity in Ecuador, Panama and El Salvador and leave-one-out checks.

03_crisis_cases_ARG_BOL.do
    Reproduces the matched Argentina Aug-2019 and Bolivia Jun-2024 +/-6-month crisis comparisons.
    Controls: ARG={BRA,MEX,PER,CHL,DOM}; BOL={SLV,ECU,PRY,PER,BRA}.

04_parallel_fx_shadow_price.do
    Argentina, Bolivia and Venezuela parallel-FX premium models with linear trend, month-of-year controls,
    and Newey-West HAC(3) standard errors.

05_debt_US_yields_main.do
    Main macro result: debt/GDP interacted with US2Y and US10Y in LATAM, threshold gradient (50/60/75),
    full-26 comparison, Japan exclusion and yield-curve robustness.

06_debt_yields_ex_dollarized.do
    Repeats the key debt x US-yield models after excluding ECU, PAN and SLV.

07_reserves_transmission_robustness.do
    Triple interactions of global financial conditions x debt/GDP x reserves/GDP. This is a mechanism
    robustness test and does NOT replace the main two-way debt x yield result.

08_Bolivia_BCB_reserves.do
    Specialized Bolivia monthly BCB reserve analysis using the separate BCB CSV.

09_run_all.do
    Runs 00 through 08 automatically.

DATA FILES
- LATAM18_ADV8_stablecoin_macro_MASTER_FINAL_2018_2025.csv
- Bolivia_BCB_monthly_reserves_stablecoins_2018_2025.csv

IMPORTANT REPLICATION NOTES
- Main panel estimator: OLS with country FE + calendar-month FE and country-clustered standard errors.
- The US rate/yield main effect is absorbed by calendar-month FE; the interaction remains identified.
- Annual WDI and IMF WEO variables are repeated within year, not interpolated.
- Parallel-FX regressions are exploratory time-series models, not causal estimates.
- Bolivia BCB reserve models are exploratory because the monthly reserve window is short.
- Stata and Python/statsmodels use somewhat different finite-sample corrections for clustered/HAC
  covariance matrices. Point estimates should reproduce; some standard errors/p-values can differ slightly,
  especially in very small-cluster specifications.
- The primary gross-flows/GDP result has normalization sensitivity; the scripts deliberately retain those
  robustness checks rather than hiding them.
- The reserve triple interaction is reported as a justified robustness/mechanism test: predicted signs,
  imprecise estimates, no claim that reserve depletion is an established transmission channel.
