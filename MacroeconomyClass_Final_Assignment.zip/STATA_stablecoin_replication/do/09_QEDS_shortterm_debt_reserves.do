version 16
clear all
set more off
capture log close
log using "$OUT/09_QEDS_shortterm_debt_reserves.log", replace text
use "$DATA/master_replication.dta", clear

* ============================================================
* 09 QEDS SHORT-TERM EXTERNAL DEBT / RESERVES
* External-liquidity mechanism test.
*
* Core vulnerability measure:
*   x_shortterm_extdebt_reserves = QEDS short-term external debt /
*                                  reserves excluding gold
*
* Question: do tighter US financial conditions generate more stablecoin
* activity where near-term external obligations are large relative to the
* country's reserve buffer?
*
* Inference:
*   conventional country-clustered SEs + wild-cluster bootstrap-t.
* ============================================================

capture confirm variable x_shortterm_extdebt_reserves
if _rc {
    di as error "Updated QEDS master is required: x_shortterm_extdebt_reserves not found."
    exit 111
}

capture which boottest
if _rc {
    di as error "boottest is required. Install once with: ssc install boottest"
    exit 499
}

local reps 9999
local seed 20261017

* ------------------------------------------------------------
* A. Ratio alone: country + month FE
* ------------------------------------------------------------
di as result "---- QEDS: short-term external debt / reserves, LATAM ----"
reg x_log1p_gross_pct_gdp c.x_shortterm_extdebt_reserves ///
    i.country_id i.mdate if x_latam==1 & x_qeds_available==1, vce(cluster country_id)
boottest x_shortterm_extdebt_reserves, cluster(country_id) reps(`reps') ///
    seed(`seed') weight(rademacher) nograph

* ------------------------------------------------------------
* B. US yields x short-term debt/reserves, LATAM
* US-yield main effects are absorbed by month FE.
* ------------------------------------------------------------
foreach r in us_treasury_2y_pct_mean us_treasury_10y_pct_mean {
    di as result "---- LATAM: `r' x short-term debt/reserves ----"
    reg x_log1p_gross_pct_gdp ///
        c.`r'#c.x_shortterm_extdebt_reserves c.x_shortterm_extdebt_reserves ///
        i.country_id i.mdate if x_latam==1 & x_qeds_available==1, vce(cluster country_id)

    boottest c.`r'#c.x_shortterm_extdebt_reserves, cluster(country_id) ///
        reps(`reps') seed(`seed') weight(rademacher) nograph
}

* ------------------------------------------------------------
* C. Exclude dollarized economies: ECU, PAN, SLV
* This is the theoretically cleaner monetary-sovereignty specification.
* ------------------------------------------------------------
foreach r in us_treasury_2y_pct_mean us_treasury_10y_pct_mean {
    di as result "---- LATAM ex dollarized: `r' x short-term debt/reserves ----"
    reg x_log1p_gross_pct_gdp ///
        c.`r'#c.x_shortterm_extdebt_reserves c.x_shortterm_extdebt_reserves ///
        i.country_id i.mdate ///
        if x_latam_non_dollarized==1 & x_qeds_available==1, vce(cluster country_id)

    boottest c.`r'#c.x_shortterm_extdebt_reserves, cluster(country_id) ///
        reps(`reps') seed(`seed') weight(rademacher) nograph
}

* Coverage note: QEDS is not available for every LATAM18 country/month.
* The updated master deliberately preserves the full original panel and leaves
* QEDS variables missing outside their observed coverage; regressions above
* therefore use the available QEDS subsample without altering the master.

log close
