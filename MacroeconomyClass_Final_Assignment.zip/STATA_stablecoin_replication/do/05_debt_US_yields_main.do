version 16
clear all
set more off
capture log close
log using "$OUT/05_debt_US_yields_main.log", replace text
use "$DATA/master_replication.dta", clear

* ============================================================
* 05 KEY MACRO RESULT: public debt x US Treasury yields
* Month FE absorb the common US-yield level. The interaction asks
* whether countries with higher debt respond more strongly.
* ============================================================

* ----- LATAM18: continuous debt -----
reg x_log1p_gross_pct_gdp c.us_treasury_2y_pct_mean#c.x_general_gov_gross_debt_pct_gdp ///
    c.x_general_gov_gross_debt_pct_gdp i.country_id i.mdate ///
    if x_latam==1, vce(cluster country_id)

reg x_log1p_gross_pct_gdp c.us_treasury_10y_pct_mean#c.x_general_gov_gross_debt_pct_gdp ///
    c.x_general_gov_gross_debt_pct_gdp i.country_id i.mdate ///
    if x_latam==1, vce(cluster country_id)

* Expected continuous LATAM coefficients from Python:
* US2Y x debt ≈ +0.000528, p ≈ .000480
* US10Y x debt ≈ +0.000736, p ≈ .000007


* ----- Explicit LATAM vs advanced-economy interaction tests -----
* These models directly test whether the debt x US-yield relationship differs
* between LATAM and advanced economies. Main effects absorbed by country/month
* FE may be omitted automatically; the interaction coefficients remain identified.

* US 2-year Treasury yield
reg x_log1p_gross_pct_gdp ///
    c.us_treasury_2y_pct_mean##c.x_general_gov_gross_debt_pct_gdp##i.x_latam ///
    i.country_id i.mdate, vce(cluster country_id)

* Debt x US2Y slope in advanced economies (x_latam=0)
lincom c.us_treasury_2y_pct_mean#c.x_general_gov_gross_debt_pct_gdp

* Debt x US2Y slope in LATAM (x_latam=1)
lincom c.us_treasury_2y_pct_mean#c.x_general_gov_gross_debt_pct_gdp + ///
    1.x_latam#c.us_treasury_2y_pct_mean#c.x_general_gov_gross_debt_pct_gdp

* US 10-year Treasury yield
reg x_log1p_gross_pct_gdp ///
    c.us_treasury_10y_pct_mean##c.x_general_gov_gross_debt_pct_gdp##i.x_latam ///
    i.country_id i.mdate, vce(cluster country_id)

* Debt x US10Y slope in advanced economies (x_latam=0)
lincom c.us_treasury_10y_pct_mean#c.x_general_gov_gross_debt_pct_gdp

* Debt x US10Y slope in LATAM (x_latam=1)
lincom c.us_treasury_10y_pct_mean#c.x_general_gov_gross_debt_pct_gdp + ///
    1.x_latam#c.us_treasury_10y_pct_mean#c.x_general_gov_gross_debt_pct_gdp

* The three-way interaction coefficient in each regression directly tests
* whether the debt x US-yield slope differs between LATAM and advanced economies.

* ----- LATAM thresholds: 50, 60, 75 -----
foreach t in 50 60 75 {
    di as result "---- US2Y x debt >= `t'% ----"
    reg x_log1p_gross_pct_gdp c.us_treasury_2y_pct_mean#i.x_debt_gdp_ge_`t' ///
        i.x_debt_gdp_ge_`t' i.country_id i.mdate if x_latam==1, vce(cluster country_id)

    di as result "---- US10Y x debt >= `t'% ----"
    reg x_log1p_gross_pct_gdp c.us_treasury_10y_pct_mean#i.x_debt_gdp_ge_`t' ///
        i.x_debt_gdp_ge_`t' i.country_id i.mdate if x_latam==1, vce(cluster country_id)
}

* Reference US10Y threshold gradient:
* >=50: +0.053609, p=.136
* >=60: +0.065841, p=.0486
* >=75: +0.074609, p=.00378

* ----- Full 26-country comparison -----
reg x_log1p_gross_pct_gdp c.us_treasury_10y_pct_mean#c.x_general_gov_gross_debt_pct_gdp ///
    c.x_general_gov_gross_debt_pct_gdp i.country_id i.mdate, vce(cluster country_id)

* ----- Full sample excluding Japan -----
reg x_log1p_gross_pct_gdp c.us_treasury_10y_pct_mean#c.x_general_gov_gross_debt_pct_gdp ///
    c.x_general_gov_gross_debt_pct_gdp i.country_id i.mdate ///
    if country!="JPN", vce(cluster country_id)

* ----- Yield-curve slope robustness -----
reg x_log1p_gross_pct_gdp c.us_10y_minus_2y_pp#c.x_general_gov_gross_debt_pct_gdp ///
    c.x_general_gov_gross_debt_pct_gdp i.country_id i.mdate ///
    if x_latam==1, vce(cluster country_id)

log close
