version 16
clear all
set more off
capture log close
log using "$OUT/08_Bolivia_BCB_reserves.log", replace text

* ============================================================
* 08 SPECIALIZED BOLIVIA MONTHLY BCB RESERVES
* Exploratory mechanism evidence only.
* BCB reserve observations: Jan-2023 to Apr-2025.
*
* Inference:
*   (1) original heteroskedasticity-robust p-values
*   (2) 4-month non-overlapping block bootstrap p-values.
*       Resampling blocks rather than individual months preserves some
*       short-run serial dependence in this very short time series.
* ============================================================

import delimited "$DATA/Bolivia_BCB_monthly_reserves_stablecoins_2018_2025.csv", ///
    clear varnames(1) encoding(UTF-8)
gen mdate = monthly(substr(year_month,1,7),"YM")
format mdate %tm
tsset mdate
gen trend = mdate - ym(2018,1) + 1
gen ln_rin = ln(rin_usd_mn)

summarize rin_usd_mn rin_mom_pct rin_yoy_pct x_gross_flows_pct_gdp ///
    if !missing(rin_usd_mn)

local reps 9999
local seed 20261017

* Helper: create fixed 4-month blocks in chronological order.
sort mdate
gen long block4 = floor((_n-1)/4) + 1

* Descriptive contemporaneous reserve association.
reg y rin_usd_mn x_inflation_yoy_pct_final trend if !missing(rin_usd_mn), vce(robust)
bootstrap _b[rin_usd_mn], reps(`reps') seed(`seed') cluster(block4) nodots: ///
    regress y rin_usd_mn x_inflation_yoy_pct_final trend if !missing(rin_usd_mn)

gen byte sample_mom = !missing(y, rin_mom_pct, x_inflation_yoy_pct_final, trend)
reg y rin_mom_pct x_inflation_yoy_pct_final trend if sample_mom, vce(robust)
bootstrap _b[rin_mom_pct], reps(`reps') seed(`seed') cluster(block4) nodots: ///
    regress y rin_mom_pct x_inflation_yoy_pct_final trend if sample_mom

gen byte sample_yoy = !missing(y, rin_yoy_pct, x_inflation_yoy_pct_final, trend)
reg y rin_yoy_pct x_inflation_yoy_pct_final trend if sample_yoy, vce(robust)
bootstrap _b[rin_yoy_pct], reps(`reps') seed(`seed') cluster(block4) nodots: ///
    regress y rin_yoy_pct x_inflation_yoy_pct_final trend if sample_yoy

* Low-reserve indicator used in the exploratory exercise.
gen byte sample_low = !missing(y, low_rin, x_inflation_yoy_pct_final, trend)
reg y i.low_rin x_inflation_yoy_pct_final trend if sample_low, vce(robust)
bootstrap _b[1.low_rin], reps(`reps') seed(`seed') cluster(block4) nodots: ///
    regress y i.low_rin x_inflation_yoy_pct_final trend if sample_low

* Treat these as fragile/trending time-series associations, not causal evidence.
* The block bootstrap is included for completeness; the short sample remains
* the dominant limitation and should be stated explicitly in the paper.
log close
