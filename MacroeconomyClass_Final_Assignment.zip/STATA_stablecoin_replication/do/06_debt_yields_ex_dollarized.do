version 16
clear all
set more off
capture log close
log using "$OUT/06_debt_yields_ex_dollarized.log", replace text
use "$DATA/master_replication.dta", clear

* ============================================================
* 06 ROBUSTNESS: LATAM excluding ECU, PAN and SLV
* ============================================================

reg x_log1p_gross_pct_gdp c.us_treasury_2y_pct_mean#c.x_general_gov_gross_debt_pct_gdp ///
    c.x_general_gov_gross_debt_pct_gdp i.country_id i.mdate ///
    if x_latam_non_dollarized==1, vce(cluster country_id)

reg x_log1p_gross_pct_gdp c.us_treasury_10y_pct_mean#c.x_general_gov_gross_debt_pct_gdp ///
    c.x_general_gov_gross_debt_pct_gdp i.country_id i.mdate ///
    if x_latam_non_dollarized==1, vce(cluster country_id)

foreach t in 50 60 75 {
    reg x_log1p_gross_pct_gdp c.us_treasury_2y_pct_mean#i.x_debt_gdp_ge_`t' ///
        i.x_debt_gdp_ge_`t' i.country_id i.mdate ///
        if x_latam_non_dollarized==1, vce(cluster country_id)

    reg x_log1p_gross_pct_gdp c.us_treasury_10y_pct_mean#i.x_debt_gdp_ge_`t' ///
        i.x_debt_gdp_ge_`t' i.country_id i.mdate ///
        if x_latam_non_dollarized==1, vce(cluster country_id)
}

* Reference continuous results:
* US2Y x debt ≈ +0.000545, p=.000345
* US10Y x debt ≈ +0.000758, p=.000004
* Reference >=75:
* US2Y ≈ +0.05278, p=.00719
* US10Y ≈ +0.09030, p=.00245

log close
