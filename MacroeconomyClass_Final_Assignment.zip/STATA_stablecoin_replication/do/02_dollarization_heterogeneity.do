version 16
clear all
set more off
capture log close
log using "$OUT/02_dollarization_heterogeneity.log", replace text
use "$DATA/master_replication.dta", clear

* ============================================================
* 02 FORMAL DOLLARIZATION HETEROGENEITY
* Dollarized LATAM = Ecuador, Panama, El Salvador.
* ============================================================

reg x_log1p_gross_pct_gdp c.x_inflation_yoy_pct_final##i.x_dollarized ///
    i.country_id i.mdate if x_latam==1, vce(cluster country_id)

* Implied inflation slope in dollarized economies
lincom x_inflation_yoy_pct_final + 1.x_dollarized#c.x_inflation_yoy_pct_final

* Leave-one-dollarized-country-out checks
foreach omit in ECU PAN SLV {
    di as result "---- Excluding `omit' ----"
    reg x_log1p_gross_pct_gdp c.x_inflation_yoy_pct_final##i.x_dollarized ///
        i.country_id i.mdate if x_latam==1 & country!="`omit'", vce(cluster country_id)
}

* Separate descriptive country slopes for the three dollarized economies
foreach c in ECU PAN SLV {
    di as result "---- `c' time-series slope ----"
    reg x_log1p_gross_pct_gdp x_inflation_yoy_pct_final c.mdate i.moy ///
        if country=="`c'", vce(robust)
}

log close
