version 16
clear all
set more off
capture log close
log using "$OUT/01_baseline_inflation.log", replace text
use "$DATA/master_replication.dta", clear

* ============================================================
* 01 BASELINE: inflation and stablecoin activity
* Country FE + calendar-month FE; SE clustered by country.
* Main outcome: log(1 + monthly gross stablecoin flows as % annual GDP)
* ============================================================

* LATAM baseline
reg x_log1p_gross_pct_gdp x_inflation_yoy_pct_final i.country_id i.mdate ///
    if x_latam==1, vce(cluster country_id)


* ----- Explicit LATAM vs advanced-economy comparison -----
* x_latam itself is absorbed by country FE. The interaction tests whether
* the inflation slope differs between LATAM and advanced economies.
reg x_log1p_gross_pct_gdp c.x_inflation_yoy_pct_final##i.x_latam ///
    i.country_id i.mdate, vce(cluster country_id)

* Implied inflation slope for advanced economies (x_latam=0)
lincom x_inflation_yoy_pct_final

* Implied inflation slope for LATAM (x_latam=1)
lincom x_inflation_yoy_pct_final + 1.x_latam#c.x_inflation_yoy_pct_final

* The coefficient on 1.x_latam#c.x_inflation_yoy_pct_final directly tests
* whether the LATAM inflation slope differs from the advanced-economy slope.

* Wild-cluster bootstrap for the LATAM vs advanced comparison, if boottest is installed.
* We run three clearly labelled tests.
* Test 1: Advanced-economy inflation slope = 0.
* Test 2: LATAM inflation slope = 0.
* Test 3: LATAM inflation slope - advanced-economy inflation slope = 0.
*
* boottest does not reliably accept the lincom-style sum of factor-variable
* coefficients used above. For Test 2 we therefore re-estimate the IDENTICAL
* interaction model with LATAM (x_latam=1) as the factor-variable base group.
* This changes only the parameterization: fitted values and the model are unchanged.
capture which boottest
if !_rc {

    di as text "WILD BOOTSTRAP TEST 1: ADVANCED-ECONOMY INFLATION SLOPE = 0"
    * Advanced economies are the reference group in the original parameterization.
    reg x_log1p_gross_pct_gdp c.x_inflation_yoy_pct_final##ib0.x_latam ///
        i.country_id i.mdate, vce(cluster country_id)
    boottest x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)

    di as text "WILD BOOTSTRAP TEST 2: LATAM INFLATION SLOPE = 0"
    * Rebase x_latam so LATAM is the reference group; the main inflation
    * coefficient is now exactly the implied LATAM slope reported by lincom above.
    reg x_log1p_gross_pct_gdp c.x_inflation_yoy_pct_final##ib1.x_latam ///
        i.country_id i.mdate, vce(cluster country_id)
    boottest x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)

    di as text "WILD BOOTSTRAP TEST 3: LATAM VS ADVANCED DIFFERENCE IN INFLATION SLOPES = 0"
    * Return to advanced economies as the reference group.
    reg x_log1p_gross_pct_gdp c.x_inflation_yoy_pct_final##ib0.x_latam ///
        i.country_id i.mdate, vce(cluster country_id)
    boottest 1.x_latam#c.x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)
}
else di as text "boottest not installed; conventional clustered LATAM-vs-advanced results reported above."

* ============================================================
* Inflation + domestic FX depreciation
* ============================================================
reg x_log1p_gross_pct_gdp x_inflation_yoy_pct_final x_fx_dep_mom_pct ///
    i.country_id i.mdate if x_latam==1, vce(cluster country_id)

* Wild-cluster bootstrap for BOTH coefficients in the FX-control specification.
capture which boottest
if !_rc {
    di as text "WILD BOOTSTRAP: INFLATION COEFFICIENT, CONTROLLING FOR FX DEPRECIATION"
    boottest x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)

    di as text "WILD BOOTSTRAP: DOMESTIC FX DEPRECIATION COEFFICIENT"
    boottest x_fx_dep_mom_pct, ///
        cluster(country_id) reps(9999) seed(20261007)
}
else di as text "boottest not installed; conventional clustered FX-control results reported above."

* ============================================================
* Outcome-normalization robustness
* Same LATAM-only inflation specification, alternative dependent variables.
* Each regression is followed by a wild-cluster bootstrap for inflation.
* ============================================================

di as text "ROBUSTNESS OUTCOME 1: LOG(1 + GROSS FLOWS PER CAPITA)"

* 1A. LATAM-only per-capita inflation slope
reg x_log1p_gross_per_capita x_inflation_yoy_pct_final ///
    i.country_id i.mdate if x_latam==1, vce(cluster country_id)
capture which boottest
if !_rc {
    di as text "WILD BOOTSTRAP PER CAPITA TEST 1: LATAM-ONLY INFLATION SLOPE = 0"
    boottest x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)
}

* 1B. LATAM versus advanced economies using the per-capita outcome.
* Advanced economies (x_latam=0) are the reference group.
reg x_log1p_gross_per_capita c.x_inflation_yoy_pct_final##ib0.x_latam ///
    i.country_id i.mdate, vce(cluster country_id)

di as text "PER CAPITA: IMPLIED INFLATION SLOPE FOR ADVANCED ECONOMIES"
lincom x_inflation_yoy_pct_final

di as text "PER CAPITA: IMPLIED INFLATION SLOPE FOR LATAM"
lincom x_inflation_yoy_pct_final + 1.x_latam#c.x_inflation_yoy_pct_final

capture which boottest
if !_rc {
    di as text "WILD BOOTSTRAP PER CAPITA TEST 2: ADVANCED INFLATION SLOPE = 0"
    boottest x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)

    di as text "WILD BOOTSTRAP PER CAPITA TEST 3: LATAM VS ADVANCED DIFFERENCE IN SLOPES = 0"
    boottest 1.x_latam#c.x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)

    * Rebase LATAM as the reference group so the inflation coefficient
    * equals the implied LATAM slope.
    di as text "WILD BOOTSTRAP PER CAPITA TEST 4: LATAM INFLATION SLOPE = 0"
    reg x_log1p_gross_per_capita c.x_inflation_yoy_pct_final##ib1.x_latam ///
        i.country_id i.mdate, vce(cluster country_id)
    boottest x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)

    * Restore advanced economies as reference.
    reg x_log1p_gross_per_capita c.x_inflation_yoy_pct_final##ib0.x_latam ///
        i.country_id i.mdate, vce(cluster country_id)
}
else di as text "boottest not installed; conventional clustered per-capita results reported above."

di as text "ROBUSTNESS OUTCOME 2: ASINH GROSS STABLECOIN FLOWS (USD)"
reg x_asinh_gross_flows x_inflation_yoy_pct_final ///
    i.country_id i.mdate if x_latam==1, vce(cluster country_id)
capture which boottest
if !_rc {
    boottest x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)
}

di as text "ROBUSTNESS OUTCOME 3: ASINH STABLECOIN HOLDINGS"
reg x_asinh_holdings x_inflation_yoy_pct_final ///
    i.country_id i.mdate if x_latam==1, vce(cluster country_id)
capture which boottest
if !_rc {
    boottest x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)
}

* Original LATAM-only main-outcome bootstrap retained for completeness.
di as text "WILD BOOTSTRAP: ORIGINAL LATAM-ONLY MAIN OUTCOME"
reg x_log1p_gross_pct_gdp x_inflation_yoy_pct_final i.country_id i.mdate ///
    if x_latam==1, vce(cluster country_id)
capture which boottest
if !_rc {
    boottest x_inflation_yoy_pct_final, ///
        cluster(country_id) reps(9999) seed(20261007)
}
else di as text "boottest not installed; conventional clustered LATAM-only result reported above."

log close
