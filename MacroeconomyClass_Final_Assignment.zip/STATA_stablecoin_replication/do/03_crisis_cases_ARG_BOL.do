version 16
clear all
set more off
capture log close
log using "$OUT/03_crisis_cases_ARG_BOL.log", replace text
use "$DATA/master_replication.dta", clear

* ============================================================
* 03 MATCHED CRISIS CASES + SMALL-CLUSTER INFERENCE
*
* Main design:
*   - matched controls selected in the original pre-event exercise
*   - event window = event month +/- 6 months
*   - post03 = event month through +3
*   - country FE + relative-month FE
*
* Additions:
*   (1) wild-cluster bootstrap for the DiD interaction
*   (2) explicit event-study / joint pre-trend test
*   (3) robustness using all LATAM countries as controls
*
* relmonth_fe maps relative month -6..+6 to 0..12.
* relmonth_fe==5 corresponds to relative month -1 and is the
* omitted reference month in the event-study regressions.
* ============================================================

capture which boottest
if _rc {
    di as error "boottest is required for wild-cluster inference."
    di as error "Install once with: ssc install boottest"
    exit 199
}

* ============================================================
* A. ARGENTINA: August 2019
* ============================================================

* ---------- A1. Matched-control DiD ----------
preserve
local ev = ym(2019,8)
keep if inlist(country,"ARG","BRA","MEX","PER","CHL","DOM")
keep if inrange(mdate,`ev'-6,`ev'+6)
gen byte treated = country=="ARG"
gen byte post03 = inrange(mdate,`ev',`ev'+3)
gen relmonth = mdate-`ev'
gen byte relmonth_fe = relmonth + 6

di as result "===== ARGENTINA: MATCHED-CONTROL DiD ====="
reg x_log1p_gross_pct_gdp i.treated##i.post03 i.country_id i.relmonth_fe, ///
    vce(cluster country_id)
lincom 1.treated#1.post03
boottest 1.treated#1.post03, cluster(country_id) reps(9999) seed(20261017)

* Event study: relative month -1 is reference.
* The joint test below asks whether the treated-control gaps at
* -6,-5,-4,-3,-2 are jointly zero.
di as result "===== ARGENTINA: MATCHED-CONTROL EVENT STUDY / PRE-TRENDS ====="
reg x_log1p_gross_pct_gdp ib5.relmonth_fe##i.treated i.country_id, ///
    vce(cluster country_id)
test 1.treated#0.relmonth_fe ///
     1.treated#1.relmonth_fe ///
     1.treated#2.relmonth_fe ///
     1.treated#3.relmonth_fe ///
     1.treated#4.relmonth_fe
restore

* ---------- A2. All-LATAM robustness ----------
preserve
local ev = ym(2019,8)
keep if x_latam==1
keep if inrange(mdate,`ev'-6,`ev'+6)
gen byte treated = country=="ARG"
gen byte post03 = inrange(mdate,`ev',`ev'+3)
gen relmonth = mdate-`ev'
gen byte relmonth_fe = relmonth + 6

di as result "===== ARGENTINA: ALL-LATAM ROBUSTNESS ====="
reg x_log1p_gross_pct_gdp i.treated##i.post03 i.country_id i.relmonth_fe, ///
    vce(cluster country_id)
lincom 1.treated#1.post03
boottest 1.treated#1.post03, cluster(country_id) reps(9999) seed(20261017)

di as result "===== ARGENTINA: ALL-LATAM EVENT STUDY / PRE-TRENDS ====="
reg x_log1p_gross_pct_gdp ib5.relmonth_fe##i.treated i.country_id, ///
    vce(cluster country_id)
test 1.treated#0.relmonth_fe ///
     1.treated#1.relmonth_fe ///
     1.treated#2.relmonth_fe ///
     1.treated#3.relmonth_fe ///
     1.treated#4.relmonth_fe
restore

* ============================================================
* B. BOLIVIA: June 2024
* ============================================================

* ---------- B1. Matched-control DiD ----------
preserve
local ev = ym(2024,6)
keep if inlist(country,"BOL","SLV","ECU","PRY","PER","BRA")
keep if inrange(mdate,`ev'-6,`ev'+6)
gen byte treated = country=="BOL"
gen byte post03 = inrange(mdate,`ev',`ev'+3)
gen relmonth = mdate-`ev'
gen byte relmonth_fe = relmonth + 6

di as result "===== BOLIVIA: MATCHED-CONTROL DiD ====="
reg x_log1p_gross_pct_gdp i.treated##i.post03 i.country_id i.relmonth_fe, ///
    vce(cluster country_id)
lincom 1.treated#1.post03
boottest 1.treated#1.post03, cluster(country_id) reps(9999) seed(20261017)

di as result "===== BOLIVIA: MATCHED-CONTROL EVENT STUDY / PRE-TRENDS ====="
reg x_log1p_gross_pct_gdp ib5.relmonth_fe##i.treated i.country_id, ///
    vce(cluster country_id)
test 1.treated#0.relmonth_fe ///
     1.treated#1.relmonth_fe ///
     1.treated#2.relmonth_fe ///
     1.treated#3.relmonth_fe ///
     1.treated#4.relmonth_fe
restore

* ---------- B2. All-LATAM robustness ----------
preserve
local ev = ym(2024,6)
keep if x_latam==1
keep if inrange(mdate,`ev'-6,`ev'+6)
gen byte treated = country=="BOL"
gen byte post03 = inrange(mdate,`ev',`ev'+3)
gen relmonth = mdate-`ev'
gen byte relmonth_fe = relmonth + 6

di as result "===== BOLIVIA: ALL-LATAM ROBUSTNESS ====="
reg x_log1p_gross_pct_gdp i.treated##i.post03 i.country_id i.relmonth_fe, ///
    vce(cluster country_id)
lincom 1.treated#1.post03
boottest 1.treated#1.post03, cluster(country_id) reps(9999) seed(20261017)

di as result "===== BOLIVIA: ALL-LATAM EVENT STUDY / PRE-TRENDS ====="
reg x_log1p_gross_pct_gdp ib5.relmonth_fe##i.treated i.country_id, ///
    vce(cluster country_id)
test 1.treated#0.relmonth_fe ///
     1.treated#1.relmonth_fe ///
     1.treated#2.relmonth_fe ///
     1.treated#3.relmonth_fe ///
     1.treated#4.relmonth_fe
restore

* Reference point estimates / diagnostic results from Python:
* Matched ARG DiD ≈ -0.003044; exact 6-cluster wild-bootstrap p ≈ .781
* Matched BOL DiD ≈ +0.107765; exact 6-cluster wild-bootstrap p ≈ .250
* All-LATAM ARG DiD ≈ +0.007891
* All-LATAM BOL DiD ≈ +0.107721
*
* Pre-trend diagnostics (joint test of relative months -6..-2):
* Matched ARG: rejected (p ≈ .0029)
* Matched BOL: rejected (p ≈ .00014)
* All-LATAM ARG: strongly rejected
* All-LATAM BOL: strongly rejected
*
* Interpretation: these short-window DiD estimates are descriptive/event
* associations, not clean causal DiD estimates, because parallel pre-trends fail.

log close
