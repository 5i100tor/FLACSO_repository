version 16
clear all
set more off

* ============================================================
* MASTER RUNNER
* Start Stata in the STATA_stablecoin_replication folder.
* This executes the project in storyline order.
* ============================================================

do "do/00_setup.do"
do "do/01_baseline_inflation.do"
do "do/02_dollarization_heterogeneity.do"
do "do/03_crisis_cases_ARG_BOL.do"
do "do/04_parallel_fx_shadow_price.do"
do "do/05_debt_US_yields_main.do"
do "do/06_debt_yields_ex_dollarized.do"
do "do/07_reserves_transmission_robustness.do"
do "do/08_Bolivia_BCB_reserves.do"
do "do/09_QEDS_shortterm_debt_reserves.do"

di as result "Replication run complete. See output/*.log"
