version 16
clear all
set more off
capture log close
log using "$OUT/07_reserves_transmission_robustness.log", replace text
use "$DATA/master_replication.dta", clear

* ============================================================
* 07 RESERVES AS A TRANSMISSION-CHANNEL ROBUSTNESS TEST
* IMPORTANT: this does NOT replace the two-way debt x yield result.
* Hypothesis: high debt + tight US conditions should matter more when
* reserve buffers are low. With reserves/GDP entered directly, the
* hypothesized triple coefficient is negative.
*
* Inference:
*   (1) conventional SEs clustered by country
*   (2) wild-cluster bootstrap-t p-values (Rademacher weights),
*       appropriate for the small number of country clusters.
* ============================================================

* boottest is required for wild-cluster inference.
capture which boottest
if _rc {
    di as error "boottest is required. Install once with: ssc install boottest"
    exit 499
}

local reps 9999
local seed 20261017

* LATAM18
foreach r in fed_funds_effective_pct_mean us_treasury_2y_pct_mean us_treasury_10y_pct_mean {
    di as result "---- LATAM: `r' x debt x reserves ----"
    reg x_log1p_gross_pct_gdp c.`r'##c.x_general_gov_gross_debt_pct_gdp##c.x_reserves_pct_gdp ///
        i.country_id i.mdate if x_latam==1, vce(cluster country_id)

    * H0: triple interaction = 0. Conventional p-value is in regression output;
    * boottest reports the wild-cluster bootstrap p-value.
    boottest c.`r'#c.x_general_gov_gross_debt_pct_gdp#c.x_reserves_pct_gdp, ///
        cluster(country_id) reps(`reps') seed(`seed') weight(rademacher) nograph
}

* LATAM excluding ECU/PAN/SLV
foreach r in fed_funds_effective_pct_mean us_treasury_2y_pct_mean us_treasury_10y_pct_mean {
    di as result "---- LATAM ex dollarized: `r' x debt x reserves ----"
    reg x_log1p_gross_pct_gdp c.`r'##c.x_general_gov_gross_debt_pct_gdp##c.x_reserves_pct_gdp ///
        i.country_id i.mdate if x_latam_non_dollarized==1, vce(cluster country_id)

    boottest c.`r'#c.x_general_gov_gross_debt_pct_gdp#c.x_reserves_pct_gdp, ///
        cluster(country_id) reps(`reps') seed(`seed') weight(rademacher) nograph
}

* Reference conventional triple coefficients from the original exercise:
* LATAM: Fed=-.000029 (p=.430); US2Y=-.000034 (p=.439); US10Y=-.000075 (p=.214)
* Ex dollarized: Fed=-.000021 (p=.553); US2Y=-.000015 (p=.711); US10Y=-.000063 (p=.255)
* Signs are directionally consistent with buffering, but statistically insignificant.

* US10Y low-reserve threshold robustness + bootstrap of the triple interaction.
foreach t in 10 15 20 {
    di as result "---- LATAM: US10Y x debt x reserves<`t'% ----"
    reg x_log1p_gross_pct_gdp ///
        c.us_treasury_10y_pct_mean##c.x_general_gov_gross_debt_pct_gdp##i.x_low_reserves_gdp_lt_`t' ///
        i.country_id i.mdate if x_latam==1, vce(cluster country_id)

    boottest c.us_treasury_10y_pct_mean#c.x_general_gov_gross_debt_pct_gdp#1.x_low_reserves_gdp_lt_`t', ///
        cluster(country_id) reps(`reps') seed(`seed') weight(rademacher) nograph
}

log close
