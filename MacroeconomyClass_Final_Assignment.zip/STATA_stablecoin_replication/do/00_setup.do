version 16
clear all
set more off
capture log close _all

* ============================================================
* 00 SETUP
* Run this first. Change ROOT only if you moved the folder.
* ============================================================
global ROOT "`c(pwd)'"
capture confirm file "$ROOT/DATA/LATAM18_ADV8_stablecoin_macro_MASTER_FINAL_2018_2025.csv"
if _rc {
    di as error "Run Stata from the STATA_stablecoin_replication folder, or edit global ROOT in 00_setup.do."
    exit 601
}
global DATA "$ROOT/DATA"
global OUT  "$ROOT/output"

import delimited "$DATA/LATAM18_ADV8_stablecoin_macro_MASTER_FINAL_2018_2025.csv", clear varnames(1) encoding(UTF-8)

* IDs and monthly time index
encode country, gen(country_id)
gen mdate = monthly(substr(year_month,1,7),"YM")
format mdate %tm
gen moy = month(dofm(mdate))
xtset country_id mdate

* Convenience variables. Originals are preserved.
capture confirm variable x_reserves_pct_gdp
if _rc gen x_reserves_pct_gdp = 100*total_reserves_excluding_gold_usd/gdp_current_usd
capture confirm variable x_latam_non_dollarized
if _rc gen byte x_latam_non_dollarized = x_latam==1 & !inlist(country,"ECU","PAN","SLV")

foreach t in 50 60 75 100 {
    capture confirm variable x_debt_gdp_ge_`t'
    if _rc gen byte x_debt_gdp_ge_`t' = x_general_gov_gross_debt_pct_gdp>=`t' if !missing(x_general_gov_gross_debt_pct_gdp)
}
foreach t in 10 15 20 {
    capture confirm variable x_low_reserves_gdp_lt_`t'
    if _rc gen byte x_low_reserves_gdp_lt_`t' = x_reserves_pct_gdp<`t' if !missing(x_reserves_pct_gdp)
}

compress
save "$DATA/master_replication.dta", replace

di as result "Setup complete: $DATA/master_replication.dta"
