version 16
clear all
set more off
capture log close
log using "$OUT/04_parallel_fx_shadow_price.log", replace text
use "$DATA/master_replication.dta", clear

* ============================================================
* 04 PARALLEL FX PREMIUM: shadow price of dollar scarcity
* Exploratory country time-series OLS, linear trend + month-of-year
* controls, Newey-West HAC(3). ARG/BOL control for inflation.
* Venezuela lacks comparable CPI coverage in this panel.
* ============================================================

gen premium100 = parallel_premium_eom_pct/100
gen premium100_sq = premium100^2
gen trend = mdate - ym(2018,1) + 1

foreach c in ARG BOL VEN {
    preserve
    keep if country=="`c'" & !missing(parallel_premium_eom_pct)
    tsset mdate

    if "`c'"!="VEN" {
        newey x_log1p_gross_pct_gdp premium100 x_inflation_yoy_pct_final trend i.moy, lag(3) force
        newey x_log1p_gross_pct_gdp x_premium_ge_50pct x_inflation_yoy_pct_final trend i.moy, lag(3) force
    }
    else {
        newey x_log1p_gross_pct_gdp premium100 trend i.moy, lag(3) force
        newey x_log1p_gross_pct_gdp x_premium_ge_50pct trend i.moy, lag(3) force
    }
    restore
}

* Reference results from original Python HAC(3) implementation:
* ARG premium +100pp: beta ≈ +0.180973, p ≈ .0108
* ARG premium >=50%: beta ≈ +0.185223, p ≈ .0026
* BOL premium +100pp: beta ≈ +1.515860 (17 premium months; very fragile)
* VEN premium +100pp: beta ≈ -0.004413, p ≈ .394
* Small numerical differences in HAC SEs may occur across implementations.

log close
