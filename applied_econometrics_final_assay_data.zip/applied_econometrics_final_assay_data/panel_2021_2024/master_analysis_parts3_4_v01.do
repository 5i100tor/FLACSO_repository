/***********************************************************************
 MASTER ANALYSIS DO-FILE — PARTS III AND IV
 Ecuador province-year vaccination panel, 2021–2024

 PART III: Rotavirus and BCG/TB fixed-effects models
 PART IV: Exploratory instrumental-variable analysis

 Final IV set retained:
   1. Yellow-fever vaccination (fa)
   2. Third-dose pentavalent vaccination (penta_3)

 Outputs:
   results_part3_part4/
       full_output/
       stored_models/
       tables/

 IMPORTANT:
 - Vaccination and hospitalization rates use estimated_population.
 - Main regression standard errors are clustered by province.
 - The built-in Sargan/Basmann overidentification tests are run only
   after supplementary non-clustered 2SLS models because Stata 16
   does not provide estat overid after cluster-robust ivregress.
 - The 2SLS specifications reproduce the finalized analysis:
   year fixed effects and province-clustered standard errors.
***********************************************************************/

version 16.0
clear all
set more off
set varabbrev off

*======================================================================*
* 0. USER PATHS
*======================================================================*

* Run this do-file from the folder containing the master panel.
* Change this filename only if your local file has a different name.
local datafile "/Users/Victor/Desktop/FLACSO/PhD_DevEcon/PhD_Modules/Mod2_AppliedEconometrics/finalProject/Analysis/2021_2024/ProvYearPanel_2021_2024_v01.dta"

* Main output directory
local results "results_part3_part4"

capture mkdir "`results'"
capture mkdir "`results'/full_output"
capture mkdir "`results'/stored_models"
capture mkdir "`results'/tables"

* Verify esttab/eststo are installed
capture which eststo
if _rc {
    display as error "The estout package is required."
    display as error "Install it once with: ssc install estout"
    exit 199
}

* Verify the input file exists
capture confirm file "`datafile'"
if _rc {
    display as error "INPUT FILE NOT FOUND: `datafile'"
    display as error "Edit local datafile at the top of this do-file."
    exit 601
}

use "`datafile'", clear


*======================================================================*
* 1. VERIFY PANEL AND REQUIRED RAW VARIABLES
*======================================================================*

capture log close _all
log using "`results'/full_output/00_verification_and_descriptives.smcl", replace

count
assert r(N) == 96

isid province_code anio
assert inrange(anio, 2021, 2024)
assert inrange(province_code, 1, 24)

bysort anio: assert _N == 24
bysort province_code: assert _N == 4

sort province_code anio
xtset province_code anio
xtdescribe
tabulate anio
duplicates report province_code anio

local required ///
    province_code anio estimated_population ///
    tb_discharges rotavirus_discharges ///
    bcg bcg_24 rota_2 fa penta_3 ///
    poverty_rate public_network_water_rate

foreach v of local required {
    capture confirm variable `v'
    if _rc {
        display as error "REQUIRED VARIABLE MISSING: `v'"
        log close
        exit 111
    }
}

assert estimated_population > 0 if !missing(estimated_population)


*======================================================================*
* 2. REPRODUCIBLY GENERATE ALL ANALYTICAL VARIABLES
*======================================================================*

capture drop rota2_rate_100k
capture drop rota_hosp_rate_100k
capture drop ln_rota_hosp

capture drop bcg_rate_100k
capture drop bcg24_rate_100k
capture drop tb_rate_100k
capture drop ln_tb_hosp

capture drop fa_rate_100k
capture drop penta3_rate_100k

gen double rota2_rate_100k = ///
    100000 * rota_2 / estimated_population

gen double rota_hosp_rate_100k = ///
    100000 * rotavirus_discharges / estimated_population

gen double ln_rota_hosp = ///
    ln(rota_hosp_rate_100k + 1)

gen double bcg_rate_100k = ///
    100000 * bcg / estimated_population

gen double bcg24_rate_100k = ///
    100000 * bcg_24 / estimated_population

gen double tb_rate_100k = ///
    100000 * tb_discharges / estimated_population

gen double ln_tb_hosp = ///
    ln(tb_rate_100k + 1)

gen double fa_rate_100k = ///
    100000 * fa / estimated_population

gen double penta3_rate_100k = ///
    100000 * penta_3 / estimated_population

label variable rota2_rate_100k ///
    "Rotavirus second doses per 100,000 population"

label variable rota_hosp_rate_100k ///
    "Rotavirus hospital discharges per 100,000 population"

label variable ln_rota_hosp ///
    "ln(Rotavirus hospitalization rate + 1)"

label variable bcg_rate_100k ///
    "BCG doses per 100,000 population"

label variable bcg24_rate_100k ///
    "BCG within 24 hours per 100,000 population"

label variable tb_rate_100k ///
    "TB hospital discharges per 100,000 population"

label variable ln_tb_hosp ///
    "ln(TB hospitalization rate + 1)"

label variable fa_rate_100k ///
    "Yellow-fever doses per 100,000 population"

label variable penta3_rate_100k ///
    "Pentavalent third doses per 100,000 population"

misstable summarize ///
    ln_rota_hosp rota2_rate_100k ///
    ln_tb_hosp bcg_rate_100k bcg24_rate_100k ///
    fa_rate_100k penta3_rate_100k ///
    poverty_rate public_network_water_rate

summarize ///
    rotavirus_discharges rota_hosp_rate_100k rota2_rate_100k ///
    tb_discharges tb_rate_100k bcg_rate_100k bcg24_rate_100k ///
    fa_rate_100k penta3_rate_100k ///
    poverty_rate public_network_water_rate

xtsum ///
    rota2_rate_100k bcg_rate_100k bcg24_rate_100k ///
    fa_rate_100k penta3_rate_100k

log close


*======================================================================*
* 3. CLEAR PREVIOUSLY STORED ESTIMATES
*======================================================================*

eststo clear
estimates clear


*======================================================================*
* PART III — VACCINATION FIXED-EFFECTS MODELS
*======================================================================*

*----------------------------------------------------------------------*
* 3.1 ROTAVIRUS MODELS
*----------------------------------------------------------------------*

capture log close _all
log using "`results'/full_output/01_rotavirus_FE_models.smcl", replace

* Model 1: core specification
eststo ROTA_FE_M1: xtreg ln_rota_hosp ///
    rota2_rate_100k ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/ROTA_FE_M1.ster", replace

* Model 2: socioeconomic controls
eststo ROTA_FE_M2: xtreg ln_rota_hosp ///
    rota2_rate_100k ///
    poverty_rate ///
    public_network_water_rate ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/ROTA_FE_M2.ster", replace

log close


*----------------------------------------------------------------------*
* 3.2 BCG / TUBERCULOSIS MODELS
*----------------------------------------------------------------------*

capture log close _all
log using "`results'/full_output/02_TB_BCG_FE_models.smcl", replace

* Model 1: core specification
eststo TB_FE_M1: xtreg ln_tb_hosp ///
    bcg_rate_100k ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/TB_FE_M1.ster", replace

* Model 2: socioeconomic controls
eststo TB_FE_M2: xtreg ln_tb_hosp ///
    bcg_rate_100k ///
    poverty_rate ///
    public_network_water_rate ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/TB_FE_M2.ster", replace

* Model 3: BCG administered within 24 hours
eststo TB_BCG24_M3: xtreg ln_tb_hosp ///
    bcg24_rate_100k ///
    poverty_rate ///
    public_network_water_rate ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/TB_BCG24_M3.ster", replace

log close


*======================================================================*
* PART IV — INSTRUMENTAL-VARIABLE ANALYSIS
*======================================================================*

*----------------------------------------------------------------------*
* 4.1 FIRST-STAGE SCREEN: BCG
*----------------------------------------------------------------------*

capture log close _all
log using "`results'/full_output/03_first_stage_BCG.smcl", replace

eststo FS_BCG_FA: xtreg bcg_rate_100k ///
    fa_rate_100k ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/FS_BCG_FA.ster", replace

eststo FS_BCG_PENTA: xtreg bcg_rate_100k ///
    penta3_rate_100k ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/FS_BCG_PENTA.ster", replace

log close


*----------------------------------------------------------------------*
* 4.2 FIRST-STAGE SCREEN: ROTAVIRUS VACCINATION
*----------------------------------------------------------------------*

capture log close _all
log using "`results'/full_output/04_first_stage_Rotavirus.smcl", replace

eststo FS_ROTA_FA: xtreg rota2_rate_100k ///
    fa_rate_100k ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/FS_ROTA_FA.ster", replace

eststo FS_ROTA_PENTA: xtreg rota2_rate_100k ///
    penta3_rate_100k ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/FS_ROTA_PENTA.ster", replace

log close


*----------------------------------------------------------------------*
* 4.3 REDUCED-FORM MODELS: TB
*----------------------------------------------------------------------*

capture log close _all
log using "`results'/full_output/05_reduced_form_TB.smcl", replace

eststo RF_TB_FA: xtreg ln_tb_hosp ///
    fa_rate_100k ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/RF_TB_FA.ster", replace

eststo RF_TB_PENTA: xtreg ln_tb_hosp ///
    penta3_rate_100k ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/RF_TB_PENTA.ster", replace

log close


*----------------------------------------------------------------------*
* 4.4 REDUCED-FORM MODELS: ROTAVIRUS
*----------------------------------------------------------------------*

capture log close _all
log using "`results'/full_output/06_reduced_form_Rotavirus.smcl", replace

eststo RF_ROTA_FA: xtreg ln_rota_hosp ///
    fa_rate_100k ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/RF_ROTA_FA.ster", replace

eststo RF_ROTA_PENTA: xtreg ln_rota_hosp ///
    penta3_rate_100k ///
    i.anio, ///
    fe vce(cluster province_code)

estimates save ///
    "`results'/stored_models/RF_ROTA_PENTA.ster", replace

log close


*----------------------------------------------------------------------*
* 4.5 2SLS MODELS: BCG -> TB
*----------------------------------------------------------------------*

capture log close _all
log using "`results'/full_output/07_IV_TB_clustered.smcl", replace

eststo IV_TB_FA: ivregress 2sls ln_tb_hosp ///
    (bcg_rate_100k = fa_rate_100k) ///
    i.anio, ///
    vce(cluster province_code)

estimates save ///
    "`results'/stored_models/IV_TB_FA.ster", replace

eststo IV_TB_PENTA: ivregress 2sls ln_tb_hosp ///
    (bcg_rate_100k = penta3_rate_100k) ///
    i.anio, ///
    vce(cluster province_code)

estimates save ///
    "`results'/stored_models/IV_TB_PENTA.ster", replace

eststo IV_TB_BOTH: ivregress 2sls ln_tb_hosp ///
    (bcg_rate_100k = penta3_rate_100k fa_rate_100k) ///
    i.anio, ///
    vce(cluster province_code)

estimates save ///
    "`results'/stored_models/IV_TB_BOTH.ster", replace

log close


*----------------------------------------------------------------------*
* 4.6 2SLS MODELS: ROTAVIRUS VACCINATION -> HOSPITALIZATION
*----------------------------------------------------------------------*

capture log close _all
log using "`results'/full_output/08_IV_Rotavirus_clustered.smcl", replace

eststo IV_ROTA_FA: ivregress 2sls ln_rota_hosp ///
    (rota2_rate_100k = fa_rate_100k) ///
    i.anio, ///
    vce(cluster province_code)

estimates save ///
    "`results'/stored_models/IV_ROTA_FA.ster", replace

eststo IV_ROTA_PENTA: ivregress 2sls ln_rota_hosp ///
    (rota2_rate_100k = penta3_rate_100k) ///
    i.anio, ///
    vce(cluster province_code)

estimates save ///
    "`results'/stored_models/IV_ROTA_PENTA.ster", replace

eststo IV_ROTA_BOTH: ivregress 2sls ln_rota_hosp ///
    (rota2_rate_100k = penta3_rate_100k fa_rate_100k) ///
    i.anio, ///
    vce(cluster province_code)

estimates save ///
    "`results'/stored_models/IV_ROTA_BOTH.ster", replace

log close


*----------------------------------------------------------------------*
* 4.7 SUPPLEMENTARY NON-CLUSTERED OVERIDENTIFICATION DIAGNOSTICS
*----------------------------------------------------------------------*

capture log close _all
log using "`results'/full_output/09_overidentification_tests.smcl", replace

display as text "============================================================"
display as text "TB OVERIDENTIFICATION DIAGNOSTIC"
display as text "Supplementary non-clustered model"
display as text "============================================================"

eststo IV_TB_BOTH_NR: ivregress 2sls ln_tb_hosp ///
    (bcg_rate_100k = penta3_rate_100k fa_rate_100k) ///
    i.anio

estimates save ///
    "`results'/stored_models/IV_TB_BOTH_nonclustered.ster", replace

estat overid

display as text "============================================================"
display as text "ROTAVIRUS OVERIDENTIFICATION DIAGNOSTIC"
display as text "Supplementary non-clustered model"
display as text "============================================================"

eststo IV_ROTA_BOTH_NR: ivregress 2sls ln_rota_hosp ///
    (rota2_rate_100k = penta3_rate_100k fa_rate_100k) ///
    i.anio

estimates save ///
    "`results'/stored_models/IV_ROTA_BOTH_nonclustered.ster", replace

estat overid

log close


*======================================================================*
* 5. EXPORT WORD-READABLE TABLES
*======================================================================*

*----------------------------------------------------------------------*
* Table 1: Main vaccination fixed-effects models
*----------------------------------------------------------------------*

esttab ///
    ROTA_FE_M1 ROTA_FE_M2 ///
    TB_FE_M1 TB_FE_M2 TB_BCG24_M3 ///
using "`results'/tables/Table1_vaccination_FE_models.rtf", replace ///
label b(6) se(6) star(* 0.10 ** 0.05 *** 0.01) ///
drop(*.anio) ///
mtitles( ///
    "Rotavirus core" ///
    "Rotavirus + controls" ///
    "BCG core" ///
    "BCG + controls" ///
    "BCG within 24h" ///
) ///
stats(N N_g r2_w r2_b r2_o F rho sigma_u sigma_e, ///
fmt(0 0 3 3 3 2 3 3 3) ///
labels( ///
    "Observations" ///
    "Provinces" ///
    "Within R-squared" ///
    "Between R-squared" ///
    "Overall R-squared" ///
    "F statistic" ///
    "Rho" ///
    "Sigma u" ///
    "Sigma e" ///
)) ///
title("Table 1. Vaccination and Disease-Specific Hospitalizations")


*----------------------------------------------------------------------*
* Table 2: First-stage models
*----------------------------------------------------------------------*

esttab ///
    FS_BCG_FA FS_BCG_PENTA ///
    FS_ROTA_FA FS_ROTA_PENTA ///
using "`results'/tables/Table2_IV_first_stage_models.rtf", replace ///
label b(6) se(6) star(* 0.10 ** 0.05 *** 0.01) ///
drop(*.anio) ///
mtitles( ///
    "BCG: Yellow fever" ///
    "BCG: Pentavalent" ///
    "Rotavirus: Yellow fever" ///
    "Rotavirus: Pentavalent" ///
) ///
stats(N N_g r2_w r2_b r2_o F rho sigma_u sigma_e, ///
fmt(0 0 3 3 3 2 3 3 3) ///
labels( ///
    "Observations" ///
    "Provinces" ///
    "Within R-squared" ///
    "Between R-squared" ///
    "Overall R-squared" ///
    "F statistic" ///
    "Rho" ///
    "Sigma u" ///
    "Sigma e" ///
)) ///
title("Table 2. Instrument Relevance: First-Stage Models")


*----------------------------------------------------------------------*
* Table 3: Reduced-form models
*----------------------------------------------------------------------*

esttab ///
    RF_TB_FA RF_TB_PENTA ///
    RF_ROTA_FA RF_ROTA_PENTA ///
using "`results'/tables/Table3_IV_reduced_form_models.rtf", replace ///
label b(6) se(6) star(* 0.10 ** 0.05 *** 0.01) ///
drop(*.anio) ///
mtitles( ///
    "TB: Yellow fever" ///
    "TB: Pentavalent" ///
    "Rotavirus: Yellow fever" ///
    "Rotavirus: Pentavalent" ///
) ///
stats(N N_g r2_w r2_b r2_o F rho sigma_u sigma_e, ///
fmt(0 0 3 3 3 2 3 3 3) ///
labels( ///
    "Observations" ///
    "Provinces" ///
    "Within R-squared" ///
    "Between R-squared" ///
    "Overall R-squared" ///
    "F statistic" ///
    "Rho" ///
    "Sigma u" ///
    "Sigma e" ///
)) ///
title("Table 3. Reduced-Form Models")


*----------------------------------------------------------------------*
* Table 4: Clustered 2SLS models for TB
*----------------------------------------------------------------------*

esttab ///
    IV_TB_FA IV_TB_PENTA IV_TB_BOTH ///
using "`results'/tables/Table4_IV_TB_clustered.rtf", replace ///
label b(7) se(7) star(* 0.10 ** 0.05 *** 0.01) ///
drop(*.anio) ///
mtitles( ///
    "Yellow fever" ///
    "Pentavalent" ///
    "Both instruments" ///
) ///
stats(N r2 chi2 p, ///
fmt(0 3 2 4) ///
labels( ///
    "Observations" ///
    "R-squared" ///
    "Wald chi-squared" ///
    "Model p-value" ///
)) ///
title("Table 4. Instrumental-Variable Models: BCG and TB Hospitalizations")


*----------------------------------------------------------------------*
* Table 5: Clustered 2SLS models for Rotavirus
*----------------------------------------------------------------------*

esttab ///
    IV_ROTA_FA IV_ROTA_PENTA IV_ROTA_BOTH ///
using "`results'/tables/Table5_IV_Rotavirus_clustered.rtf", replace ///
label b(7) se(7) star(* 0.10 ** 0.05 *** 0.01) ///
drop(*.anio) ///
mtitles( ///
    "Yellow fever" ///
    "Pentavalent" ///
    "Both instruments" ///
) ///
stats(N r2 chi2 p, ///
fmt(0 3 2 4) ///
labels( ///
    "Observations" ///
    "R-squared" ///
    "Wald chi-squared" ///
    "Model p-value" ///
)) ///
title("Table 5. Instrumental-Variable Models: Rotavirus Vaccination and Hospitalizations")


*----------------------------------------------------------------------*
* Table 6: Supplementary non-clustered overidentified specifications
*----------------------------------------------------------------------*

esttab ///
    IV_TB_BOTH_NR IV_ROTA_BOTH_NR ///
using "`results'/tables/Table6_overidentified_models_nonclustered.rtf", replace ///
label b(7) se(7) star(* 0.10 ** 0.05 *** 0.01) ///
drop(*.anio) ///
mtitles( ///
    "BCG -> TB" ///
    "Rotavirus -> hospitalization" ///
) ///
stats(N r2 chi2 p, ///
fmt(0 3 2 4) ///
labels( ///
    "Observations" ///
    "R-squared" ///
    "Wald chi-squared" ///
    "Model p-value" ///
)) ///
title("Table 6. Supplementary Overidentified 2SLS Specifications")


*======================================================================*
* 6. SAVE FINAL ANALYTICAL DATA USED BY THIS SCRIPT
*======================================================================*

save ///
    "`results'/stored_models/analysis_data_part3_part4.dta", ///
    replace


*======================================================================*
* 7. FINAL INVENTORY AND COMPLETION LOG
*======================================================================*

capture log close _all
log using "`results'/full_output/10_model_inventory.smcl", replace

display as result "============================================================"
display as result "PARTS III AND IV MASTER ANALYSIS COMPLETED"
display as result "============================================================"
display as result "DATA PERIOD: 2021-2024"
display as result "UNIT: PROVINCE-YEAR"
display as result "OBSERVATIONS: " _N
display as result "OUTPUT DIRECTORY: `results'"
display as result "INSTRUMENTS RETAINED: YELLOW FEVER AND PENTAVALENT"
display as result "============================================================"

eststo dir
estimates dir

describe
summarize ///
    ln_rota_hosp rota2_rate_100k ///
    ln_tb_hosp bcg_rate_100k bcg24_rate_100k ///
    fa_rate_100k penta3_rate_100k

log close

display as result "DONE. Parts III and IV are ready to freeze."
