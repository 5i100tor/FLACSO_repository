*******************************************************
* MASTER ANALYSIS DO-FILE: PARTS I AND II
* Reproduces the analysis recorded in:
* 2015_2024_analysis_povertyOnDisease.do
*
* Input:
* master_panel_2015_2024_no2020_v01.dta
*******************************************************

version 16
clear all
set more off
capture log close _all

local input "/Users/Victor/Desktop/FLACSO/PhD_DevEcon/PhD_Modules/Mod2_AppliedEconometrics/finalProject/Analysis/2015_2024/master_panel_2015_2024_no2020_v01.dta"

capture mkdir "results_part1_part2"
capture mkdir "results_part1_part2/tables"
capture mkdir "results_part1_part2/full_output"
capture mkdir "results_part1_part2/stored_models"

use "`input'", clear

*------------------------------------------------------*
* 1. VERIFY MASTER PANEL
*------------------------------------------------------*
assert year != 2020
count
assert r(N) == 216
isid province_code year
xtset province_code year

foreach v in province_code year population_total ///
             a09_total_n a080_n tb_total_n ///
             poverty_rate mean_income_pc ///
             public_network_water_rate unemployment_rate {
    capture confirm variable `v'
    if _rc {
        display as error "Required variable not found: `v'"
        exit 111
    }
}

assert population_total > 0 if !missing(population_total)

*------------------------------------------------------*
* 2. CREATE RATES AND LOG OUTCOMES
*------------------------------------------------------*
capture drop a09_total_rate a080_rate tb_total_rate
capture drop ln_a09_total_rate ln_a080_rate ln_tb_rate

gen double a09_total_rate = (a09_total_n / population_total) * 100000
gen double a080_rate      = (a080_n      / population_total) * 100000
gen double tb_total_rate  = (tb_total_n  / population_total) * 100000

gen double ln_a09_total_rate = ln(a09_total_rate + 1)
gen double ln_a080_rate      = ln(a080_rate + 1)
gen double ln_tb_rate        = ln(tb_total_rate + 1)

label var ln_a09_total_rate "ln(A09 hospitalization rate + 1)"
label var ln_a080_rate      "ln(Rotavirus hospitalization rate + 1)"
label var ln_tb_rate        "ln(TB hospitalization rate + 1)"

*------------------------------------------------------*
* 3. CREATE REGIONS EXACTLY AS IN THE ORIGINAL NOTES
* Province 20 (Galápagos) is grouped with Coast
*------------------------------------------------------*
capture drop region
gen byte region = .

replace region = 1 if inlist(province_code, 7,8,9,12,13,20,23,24)
replace region = 2 if inlist(province_code, 1,2,3,4,5,6,10,11,17,18)
replace region = 3 if inlist(province_code, 14,15,16,19,21,22)

label define region_lbl 1 "Coast" 2 "Highlands" 3 "Amazon", replace
label values region region_lbl
assert !missing(region)

eststo clear

*======================================================*
* PART I — SOCIOECONOMIC HYPOTHESIS
*======================================================*

*------------------------------------------------------*
* A. FIXED-EFFECTS MODELS — A09
*------------------------------------------------------*
capture log close _all
log using "results_part1_part2/full_output/FE_A09.smcl", replace

eststo FE_A09_M1: xtreg ln_a09_total_rate ///
    poverty_rate i.year, fe vce(cluster province_code)

eststo FE_A09_M2: xtreg ln_a09_total_rate ///
    poverty_rate mean_income_pc i.year, ///
    fe vce(cluster province_code)

eststo FE_A09_M3: xtreg ln_a09_total_rate ///
    poverty_rate mean_income_pc public_network_water_rate i.year, ///
    fe vce(cluster province_code)

eststo FE_A09_M4: xtreg ln_a09_total_rate ///
    poverty_rate mean_income_pc public_network_water_rate ///
    unemployment_rate i.year, fe vce(cluster province_code)

log close

*------------------------------------------------------*
* B. FIXED-EFFECTS MODELS — ROTAVIRUS
*------------------------------------------------------*
capture log close _all
log using "results_part1_part2/full_output/FE_Rotavirus.smcl", replace

eststo FE_ROTA_M1: xtreg ln_a080_rate ///
    poverty_rate i.year, fe vce(cluster province_code)

eststo FE_ROTA_M2: xtreg ln_a080_rate ///
    poverty_rate mean_income_pc i.year, ///
    fe vce(cluster province_code)

eststo FE_ROTA_M3: xtreg ln_a080_rate ///
    poverty_rate mean_income_pc public_network_water_rate i.year, ///
    fe vce(cluster province_code)

eststo FE_ROTA_M4: xtreg ln_a080_rate ///
    poverty_rate mean_income_pc public_network_water_rate ///
    unemployment_rate i.year, fe vce(cluster province_code)

log close

*------------------------------------------------------*
* C. FIXED-EFFECTS MODELS — TB
* Same nested specification for consistency
*------------------------------------------------------*
capture log close _all
log using "results_part1_part2/full_output/FE_TB.smcl", replace

eststo FE_TB_M1: xtreg ln_tb_rate ///
    poverty_rate i.year, fe vce(cluster province_code)

eststo FE_TB_M2: xtreg ln_tb_rate ///
    poverty_rate mean_income_pc i.year, ///
    fe vce(cluster province_code)

eststo FE_TB_M3: xtreg ln_tb_rate ///
    poverty_rate mean_income_pc public_network_water_rate i.year, ///
    fe vce(cluster province_code)

eststo FE_TB_M4: xtreg ln_tb_rate ///
    poverty_rate mean_income_pc public_network_water_rate ///
    unemployment_rate i.year, fe vce(cluster province_code)

log close

*------------------------------------------------------*
* D. BETWEEN ESTIMATORS — A09
*------------------------------------------------------*
capture log close _all
log using "results_part1_part2/full_output/BE_A09.smcl", replace

eststo BE_A09_M1: xtreg ln_a09_total_rate poverty_rate, be
eststo BE_A09_M2: xtreg ln_a09_total_rate ///
    poverty_rate mean_income_pc, be
eststo BE_A09_M3: xtreg ln_a09_total_rate ///
    poverty_rate mean_income_pc public_network_water_rate, be
eststo BE_A09_M4: xtreg ln_a09_total_rate ///
    poverty_rate mean_income_pc public_network_water_rate ///
    unemployment_rate, be

log close

*------------------------------------------------------*
* E. BETWEEN ESTIMATORS — ROTAVIRUS
*------------------------------------------------------*
capture log close _all
log using "results_part1_part2/full_output/BE_Rotavirus.smcl", replace

eststo BE_ROTA_M1: xtreg ln_a080_rate poverty_rate, be
eststo BE_ROTA_M2: xtreg ln_a080_rate ///
    poverty_rate mean_income_pc, be
eststo BE_ROTA_M3: xtreg ln_a080_rate ///
    poverty_rate mean_income_pc public_network_water_rate, be
eststo BE_ROTA_M4: xtreg ln_a080_rate ///
    poverty_rate mean_income_pc public_network_water_rate ///
    unemployment_rate, be

log close

*------------------------------------------------------*
* F. BETWEEN ESTIMATORS — TB
*------------------------------------------------------*
capture log close _all
log using "results_part1_part2/full_output/BE_TB.smcl", replace

eststo BE_TB_M1: xtreg ln_tb_rate poverty_rate, be
eststo BE_TB_M2: xtreg ln_tb_rate ///
    poverty_rate mean_income_pc, be
eststo BE_TB_M3: xtreg ln_tb_rate ///
    poverty_rate mean_income_pc public_network_water_rate, be
eststo BE_TB_M4: xtreg ln_tb_rate ///
    poverty_rate mean_income_pc public_network_water_rate ///
    unemployment_rate, be

log close

*======================================================*
* PART II — GEOGRAPHIC HYPOTHESIS
*======================================================*

* A09: descriptive and adjusted regional models
capture log close _all
log using "results_part1_part2/full_output/REG_A09.smcl", replace

eststo REG_A09_M1: regress ln_a09_total_rate ///
    i.region i.year, vce(cluster province_code)

eststo REG_A09_M2: regress ln_a09_total_rate ///
    poverty_rate mean_income_pc public_network_water_rate ///
    unemployment_rate i.region i.year, ///
    vce(cluster province_code)

log close

* Rotavirus: descriptive and adjusted regional models
capture log close _all
log using "results_part1_part2/full_output/REG_Rotavirus.smcl", replace

eststo REG_ROTA_M1: regress ln_a080_rate ///
    i.region i.year, vce(cluster province_code)

eststo REG_ROTA_M2: regress ln_a080_rate ///
    poverty_rate mean_income_pc public_network_water_rate ///
    unemployment_rate i.region i.year, ///
    vce(cluster province_code)

log close

* TB: descriptive and adjusted regional models
capture log close _all
log using "results_part1_part2/full_output/REG_TB.smcl", replace

eststo REG_TB_M1: regress ln_tb_rate ///
    i.region i.year, vce(cluster province_code)

eststo REG_TB_M2: regress ln_tb_rate ///
    poverty_rate mean_income_pc public_network_water_rate ///
    unemployment_rate i.region i.year, ///
    vce(cluster province_code)

log close

*------------------------------------------------------*
* 4. EXPORT WORD-READABLE TABLES
*------------------------------------------------------*

esttab FE_A09_M1 FE_A09_M2 FE_A09_M3 FE_A09_M4 using ///
"results_part1_part2/tables/Table1_FE_A09.rtf", replace ///
label b(4) se(4) star(* 0.10 ** 0.05 *** 0.01) ///
drop(*.year) mtitles("M1" "M2" "M3" "M4") ///
stats(N N_g r2_w r2_b r2_o F rho sigma_u sigma_e, ///
fmt(0 0 3 3 3 2 3 3 3) ///
labels("Observations" "Provinces" "Within R-squared" ///
"Between R-squared" "Overall R-squared" "F statistic" ///
"Rho" "Sigma u" "Sigma e")) ///
title("Fixed-Effects Models: A09")

esttab FE_ROTA_M1 FE_ROTA_M2 FE_ROTA_M3 FE_ROTA_M4 using ///
"results_part1_part2/tables/Table2_FE_Rotavirus.rtf", replace ///
label b(4) se(4) star(* 0.10 ** 0.05 *** 0.01) ///
drop(*.year) mtitles("M1" "M2" "M3" "M4") ///
stats(N N_g r2_w r2_b r2_o F rho sigma_u sigma_e, ///
fmt(0 0 3 3 3 2 3 3 3) ///
labels("Observations" "Provinces" "Within R-squared" ///
"Between R-squared" "Overall R-squared" "F statistic" ///
"Rho" "Sigma u" "Sigma e")) ///
title("Fixed-Effects Models: Rotavirus")

esttab FE_TB_M1 FE_TB_M2 FE_TB_M3 FE_TB_M4 using ///
"results_part1_part2/tables/Table3_FE_TB.rtf", replace ///
label b(4) se(4) star(* 0.10 ** 0.05 *** 0.01) ///
drop(*.year) mtitles("M1" "M2" "M3" "M4") ///
stats(N N_g r2_w r2_b r2_o F rho sigma_u sigma_e, ///
fmt(0 0 3 3 3 2 3 3 3) ///
labels("Observations" "Provinces" "Within R-squared" ///
"Between R-squared" "Overall R-squared" "F statistic" ///
"Rho" "Sigma u" "Sigma e")) ///
title("Fixed-Effects Models: Tuberculosis")

esttab BE_A09_M1 BE_A09_M2 BE_A09_M3 BE_A09_M4 using ///
"results_part1_part2/tables/Table4_BE_A09.rtf", replace ///
label b(4) se(4) star(* 0.10 ** 0.05 *** 0.01) ///
mtitles("M1" "M2" "M3" "M4") ///
stats(N N_g r2_b r2_o F, fmt(0 0 3 3 2) ///
labels("Observations" "Provinces" "Between R-squared" ///
"Overall R-squared" "F statistic")) ///
title("Between Estimators: A09")

esttab BE_ROTA_M1 BE_ROTA_M2 BE_ROTA_M3 BE_ROTA_M4 using ///
"results_part1_part2/tables/Table5_BE_Rotavirus.rtf", replace ///
label b(4) se(4) star(* 0.10 ** 0.05 *** 0.01) ///
mtitles("M1" "M2" "M3" "M4") ///
stats(N N_g r2_b r2_o F, fmt(0 0 3 3 2) ///
labels("Observations" "Provinces" "Between R-squared" ///
"Overall R-squared" "F statistic")) ///
title("Between Estimators: Rotavirus")

esttab BE_TB_M1 BE_TB_M2 BE_TB_M3 BE_TB_M4 using ///
"results_part1_part2/tables/Table6_BE_TB.rtf", replace ///
label b(4) se(4) star(* 0.10 ** 0.05 *** 0.01) ///
mtitles("M1" "M2" "M3" "M4") ///
stats(N N_g r2_b r2_o F, fmt(0 0 3 3 2) ///
labels("Observations" "Provinces" "Between R-squared" ///
"Overall R-squared" "F statistic")) ///
title("Between Estimators: Tuberculosis")

esttab REG_A09_M1 REG_A09_M2 REG_ROTA_M1 REG_ROTA_M2 ///
REG_TB_M1 REG_TB_M2 using ///
"results_part1_part2/tables/Table7_Regional_models.rtf", replace ///
label b(4) se(4) star(* 0.10 ** 0.05 *** 0.01) ///
drop(*.year) ///
mtitles("A09 Base" "A09 Adjusted" "Rota Base" "Rota Adjusted" ///
"TB Base" "TB Adjusted") ///
stats(N r2 r2_a F, fmt(0 3 3 2) ///
labels("Observations" "R-squared" "Adjusted R-squared" "F statistic")) ///
title("Regional Pooled OLS Models") ///
addnotes("Coast is the reference category.", ///
"All models include year fixed effects.", ///
"Standard errors are clustered by province.")

*------------------------------------------------------*
* 5. SAVE EACH STORED MODEL PERMANENTLY
*------------------------------------------------------*
foreach m in FE_A09_M1 FE_A09_M2 FE_A09_M3 FE_A09_M4 ///
             FE_ROTA_M1 FE_ROTA_M2 FE_ROTA_M3 FE_ROTA_M4 ///
             FE_TB_M1 FE_TB_M2 FE_TB_M3 FE_TB_M4 ///
             BE_A09_M1 BE_A09_M2 BE_A09_M3 BE_A09_M4 ///
             BE_ROTA_M1 BE_ROTA_M2 BE_ROTA_M3 BE_ROTA_M4 ///
             BE_TB_M1 BE_TB_M2 BE_TB_M3 BE_TB_M4 ///
             REG_A09_M1 REG_A09_M2 REG_ROTA_M1 REG_ROTA_M2 ///
             REG_TB_M1 REG_TB_M2 {
    estimates restore `m'
    estimates save "results_part1_part2/stored_models/`m'.ster", replace
}

*------------------------------------------------------*
* 6. CONVERT FULL LOGS TO TXT
*------------------------------------------------------*
foreach f in FE_A09 FE_Rotavirus FE_TB ///
             BE_A09 BE_Rotavirus BE_TB ///
             REG_A09 REG_Rotavirus REG_TB {
    translate "results_part1_part2/full_output/`f'.smcl" ///
              "results_part1_part2/full_output/`f'.txt", replace
}

display as result "Done. All outputs are in results_part1_part2/"
